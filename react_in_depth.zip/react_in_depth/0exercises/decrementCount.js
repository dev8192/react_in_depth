
const str = `
EventInterface                      2
    UIEventInterface                3
        MouseEventInterface         4
            DragEventInterface      5
            PointerEventInterface  11
        FocusEventInterface         6
        TouchEventInterface        12
        WheelEventInterface        14
    AnimationEventInterface         7
    ClipboardEventInterface         8
    CompositionEventInterface       9
    KeyboardEventInterface         10
    TransitionEventInterface       13`

function decrementCount(str) {
    const result = []
    const lines = str.split('\n')
    for(let i = 1; i < lines.length; i++) {
        const arr = lines[i].split(' ')
        const oldLastItem = arr[arr.length - 1]
        let newLastItem = String(Number(oldLastItem) - 1)
        if(newLastItem.length < oldLastItem.length) {
            newLastItem = newLastItem.padStart(2, ' ')
        }
        arr[arr.length - 1] = newLastItem
        result.push(arr.join(' '))
    }
    return result.join('\n')
}
console.log(decrementCount(str))
