var ELEMENT_NODE = 1;
var TEXT_NODE = 3;
var COMMENT_NODE = 8;
var DOCUMENT_NODE = 9;
var DOCUMENT_FRAGMENT_NODE = 11;
var disableCommentsAsDOMContainers = true;

function isValidContainer(node) {
    return !!(
        node && (
            node.nodeType === ELEMENT_NODE || 
            node.nodeType === DOCUMENT_NODE || 
            node.nodeType === DOCUMENT_FRAGMENT_NODE || 
            !disableCommentsAsDOMContainers
        )
    );
}

function test() {
    const node = document.createElement('div')
    console.log(isValidContainer(node))
}

function test() {
    const node = document.createElement('div')
    node.innerHTML = ' <span>123</span> '
    console.log(node.childNodes)
    console.log(node.childNodes[0])
    console.log(isValidContainer(node.childNodes[0]))
    console.log(node.childNodes[0].nodeType)
}

test()
