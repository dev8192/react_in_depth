/*
This program shows how createElement() with multiple child elements works
*/