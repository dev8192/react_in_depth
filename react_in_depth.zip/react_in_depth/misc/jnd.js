/*
    Тернарный оператор нужно запретить
*/

function jnd1(timeElapsed) {
    return timeElapsed < 120 ? 120 : timeElapsed < 480 ? 480 : timeElapsed < 1080 ? 1080 : timeElapsed < 1920 ? 1920 : timeElapsed < 3000 ? 3000 : timeElapsed < 4320 ? 4320 : Math.ceil(timeElapsed / 1960) * 1960;
}

function jnd(timeElapsed) {
    if (timeElapsed < 120) {
        return 120
    } else if (timeElapsed < 480) {
        return 480
    } else if (timeElapsed < 1080) {
        return 1080
    } else if (timeElapsed < 1920) {
        return 1920
    } else if (timeElapsed < 3000) {
        return 3000
    } else if (timeElapsed < 4320) {
        return 4320
    } else {
        return Math.ceil(timeElapsed / 1960) * 1960
    }
}

function test() {
    console.log(jnd(200))
    console.log(jnd(300))
    console.log(jnd(400))
}

test()
