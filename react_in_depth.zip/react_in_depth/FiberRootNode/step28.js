/*
TODO: FiberRootNode vs FiberNode
*/