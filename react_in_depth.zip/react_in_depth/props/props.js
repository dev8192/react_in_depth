
function Message(props) {
    return React.createElement(
        "div",
        null,
        "Message: " + props.text
    );
}

const container = document.getElementById('root')
const elem = React.createElement(Message, { text: "Hello from props" })
const root = ReactDOM.createRoot(container)
root.render(elem)
