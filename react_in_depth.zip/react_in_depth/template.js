/*
Template
*/

/****************************** react.js ******************************/
(function(exports) {
    exports.example = 'React'
})(this.React = {});

/****************************** react-dom.js ******************************/
(function(exports) {
    exports.example = 'ReactDOM'
})(this.ReactDOM = {});

/****************************** app.js ******************************/
(function() {
    console.log(React.example)
    console.log(ReactDOM.example)
})();
