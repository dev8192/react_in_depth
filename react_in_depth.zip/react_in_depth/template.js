/*
Template
*/

/****************************** react.js ******************************/
(function(exports) {
    var num = 333
    exports.example = 'React'
})(this.React = {});

/****************************** react-dom.js ******************************/
(function(exports) {
    var num = 444
    exports.example = 'ReactDOM'
})(this.ReactDOM = {});

/****************************** app.js ******************************/
(function() {
    console.log(React.example)
    console.log(ReactDOM.example)
})();
