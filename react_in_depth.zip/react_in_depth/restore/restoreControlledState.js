
// mocks
function updateWrapper() {}

function error(format) { // 41
    var _len2 = arguments.length
    var args = new Array(_len2 > 1 ? _len2 - 1 : 0)
    var _key2 = 1
    for (; _key2 < _len2; _key2++) {
        args[_key2 - 1] = arguments[_key2];
    }
    printWarning('error', format, args);
}
function printWarning(level, format, args) { // 53
    console.log(level, format, args)
}

function typeName(value) { // 202
    var hasToStringTag = typeof Symbol === 'function' && Symbol.toStringTag;
    var type = hasToStringTag && value[Symbol.toStringTag] || value.constructor.name || 'Object';
    return type;
}

function willCoercionThrow(value) { // 212
    try {
        testStringCoercion(value);
        return false;
    } catch (e) {
        return true;
    }
}
function testStringCoercion(value) { // 223
    return '' + value;
}

function checkAttributeStringCoercion(value, attributeName) { // 250
    if (willCoercionThrow(value)) {
        error('The provided `%s` attribute is an unsupported type %s.', attributeName, typeName(value));
        return testStringCoercion(value);
    }
}

function restoreControlledState(element, props) { // 1919
    var node = element;
    updateWrapper(node, props);
    updateNamedCousins(node, props);
}

function updateNamedCousins(rootNode, props) { // 1925
    var name = props.name;
    if (props.type === 'radio' && name != null) {
        var queryRoot = rootNode;
        while (queryRoot.parentNode) {
            queryRoot = queryRoot.parentNode;
        }
        checkAttributeStringCoercion(name, 'name');
        var group = queryRoot.querySelectorAll('input[name=' + JSON.stringify('' + name) + '][type="radio"]');
        for (var i = 0; i < group.length; i++) {
            var otherNode = group[i];
            if (otherNode === rootNode || otherNode.form !== rootNode.form) {
                continue;
            }
            var otherProps = getFiberCurrentPropsFromNode(otherNode);
            if (!otherProps) {
                throw new Error('ReactDOMInput: Mixing React and non-React radio inputs...');
            }
            updateValueIfChanged(otherNode);
            updateWrapper(otherNode, otherProps);
        }
    }
}

// entry point
function test1() {
    let queryRoot = document.createElement('div')
    queryRoot.innerHTML = `
    <form id="form1">
        <input type="radio" name="hello">
    </form>
    <form>
        <input type="radio" name="hello">
    </form>
    `
    const domElement = queryRoot.querySelector('#form1')
    console.log(queryRoot)
    console.log(domElement)
    let props = {
        type: 'radio',
        name: 'hello',
        // name: Symbol(),
    }
    restoreControlledState(domElement, props)
}

function test() {
    document.body.innerHTML = `
    <div class="box1">
        <div class="box2">
            <div class="box3"></div>
        </div>
    </div>
    `
    const rootNode = document.querySelector('.box3')
    let queryRoot = rootNode
    while (queryRoot.parentNode) {
        console.log(queryRoot)
        queryRoot = queryRoot.parentNode
    }
    console.log(queryRoot)
}

test()
