
// mocks
function getInstanceFromNode() {
    return {
        stateNode: 'hello',
        type: 'input',
        // type: 'textarea',
        // type: 'select',
    }
}
function getFiberCurrentPropsFromNode() {

}

function restoreControlledState(element, props) { // 1919
    console.log(element)
    // var node = element;
    // updateWrapper(node, props);
    // updateNamedCousins(node, props);
}

function restoreControlledState$1(element, props) { // 2216
    // var node = element;
    // var value = props.value;
    // if (value != null) {
    //     updateOptions(node, !!props.multiple, value, false);
    // }
}

function restoreControlledState$2(element, props) { // 2353
    // updateWrapper$1(element, props);
}

var restoreImpl = null; // 3875

function restoreStateOfTarget(target) { // 3879
    var internalInstance = getInstanceFromNode(target);
    if (!internalInstance) {
        return;
    }
    if (typeof restoreImpl !== 'function') {
        throw new Error('setRestoreImplementation() needs to be called...');
    }
    var stateNode = internalInstance.stateNode;
    if (stateNode) {
        var _props = getFiberCurrentPropsFromNode(stateNode);
        restoreImpl(internalInstance.stateNode, internalInstance.type, _props);
    }
}

function setRestoreImplementation(impl) { // 3902
    restoreImpl = impl;
}
function restoreStateIfNeeded() { // 3919
    restoreStateOfTarget()
}
function finishEventHandler() { // 3951
    restoreStateIfNeeded()
}
function batchedUpdates(fn, a, b) { // 3969
    finishEventHandler()
}
function dispatchEventWithEnableCapturePhaseSelectiveHydrationWithoutDiscreteEventReplay() { // 6474
    dispatchEventForPluginEventSystem()
}
function dispatchEventForPluginEventSystem() { // 9214
    batchedUpdates()
}

function restoreControlledState$3(domElement, tag, props) { // 10535
    switch (tag) {
        case 'input':
            restoreControlledState(domElement, props);
            return;

        case 'textarea':
            restoreControlledState$2(domElement, props);
            return;

        case 'select':
            restoreControlledState$1(domElement, props);
            return;
    }
}

setRestoreImplementation(restoreControlledState$3); // 29856

// entry point
dispatchEventWithEnableCapturePhaseSelectiveHydrationWithoutDiscreteEventReplay()
