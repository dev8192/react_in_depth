

function reducer(state, action) {
    console.log('*** reducer ***')
    if (action.type === "increment") {
        return state + 1;
    }
    if (action.type === "decrement") {
        return state - 1;
    }
    return state;
}

function App() {
    console.log('*** App ***')
    const [count, dispatch] = React.useReducer(reducer, 0);

    return React.createElement(
        "div",
        null,
        React.createElement("p", null, "Count: " + count),
        React.createElement(
            "button",
            { onClick: () => dispatch({ type: "increment" }) },
            "Increment"
        ),
        React.createElement(
            "button",
            { onClick: () => dispatch({ type: "decrement" }) },
            "Decrement"
        )
    );
}

const container = document.getElementById('root')
const elem = React.createElement(App)
const root = ReactDOM.createRoot(container)
root.render(elem)
