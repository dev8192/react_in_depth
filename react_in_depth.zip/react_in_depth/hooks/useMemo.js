/*
useMemo only matters when a calculation is expensive
and you want to avoid re‑running it unnecessarily
*/

function Demo() {
    console.log("*** Demo ***")
    const value = React.useMemo(() => {
        console.log("*** useMemo ***");
        return 42;
    }, []);

    return React.createElement(
        "div",
        null,
        "Memoized value: " + value
    );
}

const container = document.getElementById('root')
const elem = React.createElement(Demo)
const root = ReactDOM.createRoot(container)
root.render(elem)
