/*
useReducer can be easily replaced with useState
*/

function reducer(state, action) {
    console.log('*** reducer ***')
    if (action.type === "increment") {
        return state + 1;
    }
    if (action.type === "decrement") {
        return state - 1;
    }
    return state;
}

function App() {
    console.log('*** App ***')
    const [count, setValue] = React.useState(0);

    return React.createElement(
        "div",
        null,
        React.createElement("p", null, "Count: " + count),
        React.createElement(
            "button",
            { onClick: () => {
                setValue(reducer(count, { type: "increment" }))
            } },
            "Increment"
        ),
        React.createElement(
            "button",
            { onClick: () => {
                setValue(reducer(count, { type: "decrement" }))
            } },
            "Decrement"
        )
    );
}

const container = document.getElementById('root')
const elem = React.createElement(App)
const root = ReactDOM.createRoot(container)
root.render(elem)
