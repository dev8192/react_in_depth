/*
Hooks available in React 18:
useState
useEffect
useMemo
useRef
useReducer

This program shows how to use useState + useEffect
*/

function Counter() {
    const [count, setCount] = React.useState(0);

    React.useEffect(() => {
        console.log("Count changed:", count);
    }, [count]);

    return React.createElement(
        "div",
        null,
        React.createElement("p", null, "Count: " + count),
        React.createElement(
            "button",
            { onClick: () => setCount(count + 1) },
            "Increment"
        )
    );
}

const container = document.getElementById('root')
const elem = React.createElement(Counter)
const root = ReactDOM.createRoot(container)
root.render(elem)
