/*
useMemo with dependency array.
useMemo recomputes when dependencies change.
*/

function App() {
    console.log("*** App ***");
    const [count, setCount] = React.useState(0);
    const [other, setOther] = React.useState(0);

    const memoValue = React.useMemo(() => {
        console.log("*** useMemo ***");
        return count * 2;
    }, [count])

    return React.createElement(
        "div",
        null,
        React.createElement("p", null, "memoValue: " + memoValue),
        React.createElement(
            "button",
            { onClick: () => setCount(count + 1) },
            "Increment count"
        ),
        React.createElement(
            "button",
            { onClick: () => setOther(other + 1) },
            "Increment other"
        )
    );
}

const container = document.getElementById('root')
const elem = React.createElement(App)
const root = ReactDOM.createRoot(container)
root.render(elem)
