
function Demo() {
    React.useEffect(() => {
        console.log("Component mounted");
    }, []);

    return React.createElement(
        "div",
        null,
        "Check the console to see useEffect run."
    );
}

const container = document.getElementById('root')
const elem = React.createElement(Demo)
const root = ReactDOM.createRoot(container)
root.render(elem)
