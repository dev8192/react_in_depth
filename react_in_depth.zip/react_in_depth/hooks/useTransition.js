
function App() {
    console.log('*** App ***')
    const [value, setValue] = React.useState("");
    const [list, setList] = React.useState([]);
    const [isPending, startTransition] = React.useTransition();

    function handleChange(e) {
        console.log('*** handleChange ***')
        const text = e.target.value;
        setValue(text);

        startTransition(() => {
            debugger
            console.log('*** startTransition ***')
            const items = [];
            // const upperBound = 5000
            const upperBound = 5
            for (let i = 0; i < upperBound; i++) {
                items.push(text + " #" + i);
            }
            setList(items);
        });
    }

    return React.createElement(
        "div",
        null,
        React.createElement("input", {
            value: value,
            onChange: handleChange
        }),
        isPending
            ? React.createElement("p", null, "Updating list...")
            : null,
        React.createElement(
            "div",
            null,
            list.map((item, i) =>
                React.createElement("div", { key: i }, item)
            )
        )
    );
}

const container = document.getElementById('root')
const elem = React.createElement(App)
const root = ReactDOM.createRoot(document.getElementById('root'))
root.render(elem)
