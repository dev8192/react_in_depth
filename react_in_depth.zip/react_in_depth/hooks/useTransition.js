
function App() {
    const [value, setValue] = React.useState("");
    const [list, setList] = React.useState([]);
    const [isPending, startTransition] = React.useTransition();

    function handleChange(e) {
        const text = e.target.value;
        setValue(text);

        startTransition(() => {
            // simulate heavy work
            const items = [];
            for (let i = 0; i < 5000; i++) {
                items.push(text + " #" + i);
            }
            setList(items);
        });
    }

    return React.createElement(
        "div",
        null,
        React.createElement("input", {
            value: value,
            onChange: handleChange
        }),
        isPending
            ? React.createElement("p", null, "Updating list...")
            : null,
        React.createElement(
            "div",
            null,
            list.map((item, i) =>
                React.createElement("div", { key: i }, item)
            )
        )
    );
}

const root = createRoot(document.getElementById("root"));
root.render(React.createElement(App));
