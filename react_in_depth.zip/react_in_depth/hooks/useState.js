/*
useState = reactive data that drives UI updates
*/

function Counter() {
    const [value, setValue] = React.useState(0);

    return React.createElement(
        "div",
        null,
        React.createElement("p", null, "Value: " + value),
        React.createElement(
            "button",
            { onClick: () => setValue(value + 1) },
            "Increment"
        )
    );
}

const container = document.getElementById('root')
const elem = React.createElement(Counter)
const root = ReactDOM.createRoot(container)
root.render(elem)
