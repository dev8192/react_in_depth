/*
useMemo does not trigger a re-render
(useState does, when the value is updated)
*/
function Demo() {
    console.log("*** Demo ***");
    const [count, setCount] = React.useState(0);

    function slowCalculation() {
        console.log("*** slowCalculation ***")
        return 123;
    }

    const memoizedValue = React.useMemo(() => {
        return slowCalculation();
    }, []);

    return React.createElement(
        "div",
        null,
        React.createElement("p", null, "Count: " + count),
        React.createElement("p", null, "Memoized result: " + memoizedValue),
        React.createElement(
            "button",
            {
                onClick: () => {
                    console.log("*** click ***")
                    setCount(count + 1)
                }
            },
            "Re-render"
        )
    );
}

const container = document.getElementById('root')
const elem = React.createElement(Demo)
const root = ReactDOM.createRoot(container)
root.render(elem)
