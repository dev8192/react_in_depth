/*
useState is reactive, useRef is not
*/

function App() {
    const renderCount = React.useRef(0);
    const [value, setValue] = React.useState(0);

    renderCount.current += 1;

    return React.createElement(
        "div",
        null,
        React.createElement("p", null, "Renders: " + renderCount.current),
        React.createElement("p", null, "Value: " + value),
        React.createElement(
            "button",
            { onClick: () => setValue(value + 1) },
            "Increment value"
        ),
        React.createElement(
            "button",
            {
                onClick: () => {
                    renderCount.current = 0;
                    console.log("Ref reset to 0 (no re-render)");
                }
            },
            "Reset ref"
        )
    );
}

const container = document.getElementById('root')
const elem = React.createElement(App)
const root = ReactDOM.createRoot(container)
root.render(elem)
