

(function (global, factory) {
    if (typeof exports === 'object' && typeof module !== 'undefined') {
        factory(exports)
    } else if (typeof define === 'function' && define.amd) {
        define(['exports'], factory)
    } else {
        global = global || self
        factory(global.React = {})
    }
}(this, (function (exports) {
    exports.hello = 'hello'
})))

console.log(React.hello)
