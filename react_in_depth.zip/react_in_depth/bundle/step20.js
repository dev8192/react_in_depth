

(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
        typeof define === 'function' && define.amd ? define(['exports'], factory) :
            (global = global || self, factory(global.React = {}));
}(this, (function (exports) {
    function createElement(type, config, children) {
        console.log('createElement')
    }
    function createElementWithValidation(type, props, children) {
        createElement.apply(this, arguments);
    }
    var createElement$1 = createElementWithValidation
    exports.createElement = createElement$1
})))

React.createElement()
