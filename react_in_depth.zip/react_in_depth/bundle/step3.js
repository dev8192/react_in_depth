/*
Starting point
*/

(function(exports) {
    exports.example = 'React'
})(this.React = {});

console.log(React.example)
