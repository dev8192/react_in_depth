

(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
        typeof define === 'function' && define.amd ? define(['exports'], factory) :
            (global = global || self, factory(global.React = {}));
}(this, (function (exports) {
    exports.hello = 'hello'
})))

console.log(React.hello)
