

(function (global, factory) {
    console.log(global)
    console.log(factory)
    global.React = {}
    factory(global.React)
}(this, function (exports) {
    exports.hello = 'hello'
}))

console.log(React.hello)
