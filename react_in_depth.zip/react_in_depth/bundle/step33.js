/*
3-function wrapper (as in production)
*/

(function() {
    (function(c, x) {
        x(c.React = {})
    })(this, function(exports) {
        exports.example = 'React1'
    });
})();

console.log(React.example)
