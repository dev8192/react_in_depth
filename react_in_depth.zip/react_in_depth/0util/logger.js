/*
    This program shows how changes to an object property can be logged
*/

function test1() {
    var obj = {
        prop: null
    }
    console.log(obj.prop)
    obj.prop = 'hello'
    console.log(obj.prop)
    obj.prop = 'world'
    console.log(obj.prop)
}

function test1() {
    var obj = {
        _transition: null,
        set prop(value) {
            console.log(value)
            this._transition = value
        },
        get prop() {
            return this._transition
        }
    }
    console.log(obj.prop)
    obj.prop = 'hello'
    obj.prop = 'world'
}

function test() {
    function Ctor() {
        Object.defineProperty(this, 'prop', {
            __prop: null,
            set: function(value) {
                console.log('SET:', value)
                this.__prop = value
            },
            get: function() {
                console.log('GET:', this.__prop)
                return this.__prop
            }
        })
        this.prop = 333
    }
    const obj = new Ctor()
    console.log(obj.prop)
    obj.prop = 'hello'
    obj.prop = 'world'
}

test()
