
function test() {
    let workInProgress = new Proxy({}, {
        get(target, prop) {
            console.log('GET', target[prop])
            return target[prop]
        },
        set(target, prop, newValue) {
            target[prop] = newValue
            console.log('SET', target[prop])
            return true
        }
    })
    workInProgress.value = {a: 10}
    console.log('******************************')
    console.log(workInProgress.value)
    console.log('******************************')
    workInProgress.value = {a: 5}
    console.log('******************************')
    console.log(workInProgress.value)
}

test()
