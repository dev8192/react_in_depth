/*
    The order of scripts is important.
    First import react.js, then react-dom.js
*/

/****************************** react.js ******************************/
(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
        typeof define === 'function' && define.amd ? define(['exports'], factory) :
            (global = global || self, factory(global.React = {}));
}(this, (function (exports) {
    var ReactSharedInternals$1 = 'hello'
    exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = ReactSharedInternals$1
})));

/****************************** react-dom.js ******************************/
(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('react')) :
        typeof define === 'function' && define.amd ? define(['exports', 'react'], factory) :
            (global = global || self, factory(global.ReactDOM = {}, global.React));
}(this, (function (exports, React) {
    var ReactSharedInternals = React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED
    console.log(ReactSharedInternals)
})));
