/*
__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED

*/

console.log(performance.now());

/****************************** react.js ******************************/
(function(exports) {
    var getCurrentTime; // 2510
    var hasPerformanceNow = typeof performance === 'object' && typeof performance.now === 'function';
    if (hasPerformanceNow) {
        var localPerformance = performance;
        getCurrentTime = function () {
            return localPerformance.now();
        };
    } else {
        var localDate = Date;
        var initialTime = localDate.now();
        getCurrentTime = function () {
            return localDate.now() - initialTime;
        };
    }
    var Scheduler = { // 2996
        get unstable_now() { return getCurrentTime; }
    }
    var ReactSharedInternals$1 = { // 3019
        Scheduler: Scheduler
    };
    exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = ReactSharedInternals$1; // 3314
})(this.React = {});

/****************************** react-dom.js ******************************/
(function(exports) {
    var ReactInternals = React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
    var _ReactInternals$Sched = ReactInternals.Scheduler
    var unstable_now = _ReactInternals$Sched.unstable_now
    var now = unstable_now

    console.log(now())
    console.log(performance.now())
})(this.ReactDOM = {});

