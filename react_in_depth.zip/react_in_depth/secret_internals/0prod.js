/*
This program shows how secret internals are implemented in production
*/

/****************************** react.js ******************************/
(function(c) {
    function Y() {} // 30
    function K() {} // 31
    var t = (K.prototype = new Y()); // 324
    var L = { current: null },
      g = { current: null },
      J = { transition: null }; // 328
    t = { // 397
        ReactCurrentDispatcher: g,
        ReactCurrentOwner: L,
        ReactCurrentBatchConfig: J,
        Scheduler: {
            unstable_scheduleCallback: function () {
                console.log('unstable_scheduleCallback!')
            },
        }
    };
    c.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = t; // 563
})(this.React = {});

/****************************** react-dom.js ******************************/
(function(Q, zb) {
    var Sa = zb.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED // 17
    var Od = Sa.ReactCurrentDispatcher, // 8064
      Uf = Sa.ReactCurrentOwner,
      ca = Sa.ReactCurrentBatchConfig;
    function ec() {
        console.log('getInstanceFromNode')
    }
    function Ib() {
    }
    function Rc() {
    }
    function ug() {
    }
    function vg() {
    }
    function Tf() {
    }
    var ol = { usingClientEntryPoint: !1, Events: [ec, Ib, Rc, ug, vg, Tf] }; // 8508
    Q.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = ol; // 8552
})(this.ReactDOM = {}, React);

/****************************** app.js ******************************/
(function() {
    const reactInternals = React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED
    reactInternals.Scheduler.unstable_scheduleCallback()

    const reactDOMInternals = ReactDOM.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED
    reactDOMInternals.Events[0]()
})();
