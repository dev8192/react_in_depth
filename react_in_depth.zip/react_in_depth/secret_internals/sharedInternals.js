/*
We create 4 copies ReactCurrentBatchConfig
*/

/****************************** react.js ******************************/
(function(exports) {
    var ReactCurrentDispatcher = { // 55
        current: null
    };
    var ReactCurrentBatchConfig = { // 67
        transition: null
    };
    var ReactCurrentActQueue = { // 71
        current: null,
        isBatchingLegacy: false,
        didScheduleLegacyUpdate: false
    };
    var ReactCurrentOwner = { // 84
        current: null
    };
    var ReactDebugCurrentFrame = {}; // 92
    var ReactSharedInternals = { // 140
        ReactCurrentDispatcher: ReactCurrentDispatcher,
        ReactCurrentBatchConfig: ReactCurrentBatchConfig,
        ReactCurrentOwner: ReactCurrentOwner
    };
    ReactSharedInternals.ReactDebugCurrentFrame = ReactDebugCurrentFrame;
    ReactSharedInternals.ReactCurrentActQueue = ReactCurrentActQueue;

    var ReactCurrentDispatcher$1 = ReactSharedInternals.ReactCurrentDispatcher; // 1764
    var ReactDebugCurrentFrame$1 = ReactSharedInternals.ReactDebugCurrentFrame; // 2011

    var Scheduler = { // 2996
    }
    var ReactSharedInternals$1 = { // 3019
        ReactCurrentDispatcher: ReactCurrentDispatcher,
        ReactCurrentOwner: ReactCurrentOwner,
        ReactCurrentBatchConfig: ReactCurrentBatchConfig,
        Scheduler: Scheduler
    };
    ReactSharedInternals$1.ReactCurrentActQueue = ReactCurrentActQueue;
    ReactSharedInternals$1.ReactDebugCurrentFrame = ReactDebugCurrentFrame;
    exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = ReactSharedInternals$1; // 3314
})(this.React = {});

/****************************** react-dom.js ******************************/
(function(exports) {
    var ReactSharedInternals = React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED; // 17
    var ReactCurrentDispatcher = ReactSharedInternals.ReactCurrentDispatcher; // 982
    var ReactDebugCurrentFrame = ReactSharedInternals.ReactDebugCurrentFrame; // 1483
    var ReactCurrentOwner = ReactSharedInternals.ReactCurrentOwner; // 4461
    var ReactCurrentBatchConfig = ReactSharedInternals.ReactCurrentBatchConfig; // 6401

    function enqueueStateRestore() { // 3905
    }
    function restoreStateIfNeeded() { // 3919
    }
    function getInstanceFromNode() { // 11610
    }
    function getNodeFromInstance() { // 11628
    }
    function getFiberCurrentPropsFromNode() { // 11639
    }

    var ReactDebugCurrentFrame$1 = ReactSharedInternals.ReactDebugCurrentFrame; // 11656
    var ReactCurrentBatchConfig$1 = ReactSharedInternals.ReactCurrentBatchConfig; // 12754
    var ReactCurrentDispatcher$1 = ReactSharedInternals.ReactCurrentDispatcher, // 15303
        ReactCurrentBatchConfig$2 = ReactSharedInternals.ReactCurrentBatchConfig;
    var ReactCurrentOwner$1 = ReactSharedInternals.ReactCurrentOwner; // 19168
    var ReactCurrentActQueue = ReactSharedInternals.ReactCurrentActQueue; // 25290
    var ReactCurrentDispatcher$2 = ReactSharedInternals.ReactCurrentDispatcher, // 25319
        ReactCurrentOwner$2 = ReactSharedInternals.ReactCurrentOwner,
        ReactCurrentBatchConfig$3 = ReactSharedInternals.ReactCurrentBatchConfig,
        ReactCurrentActQueue$1 = ReactSharedInternals.ReactCurrentActQueue;

    function batchedUpdates$1() { // 26187
    }

    var ReactCurrentOwner$3 = ReactSharedInternals.ReactCurrentOwner; // 29529

    var Internals = { // 29854
        usingClientEntryPoint: false,
        Events: [
            getInstanceFromNode,
            getNodeFromInstance,
            getFiberCurrentPropsFromNode,
            enqueueStateRestore,
            restoreStateIfNeeded,
            batchedUpdates$1,
        ]
    };
    exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Internals
})(this.ReactDOM = {});

/****************************** app.js ******************************/
(function() {
    console.log(React.example)
    console.log(ReactDOM.example)
})();
