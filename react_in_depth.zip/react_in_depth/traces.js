/*


flushWork           react
    workLoop        react





performConcurrentWorkOnRoot
    finishConcurrentRender
        jnd




scheduleUpdateOnFiber          |
scheduleInitialHydrationOnRoot |
performConcurrentWorkOnRoot    |
performSyncWorkOnRoot          |
flushRoot                      |
commitRootImpl                 |
captureCommitPhaseErrorOnRoot  |
captureCommitPhaseError        |
pingSuspendedRoot              |
retryTimedOutBoundary
    ensureRootIsScheduled





renderRootSync
    workLoopSync




ensureRootIsScheduled
    scheduleCallback$1
        scheduleCallback


performConcurrentWorkOnRoot
    renderRootConcurrent
        workLoopConcurrent


workLoopSync | workLoopConcurrent
    performUnitOfWork
        completeUnitOfWork
            completeWork
                createInstance
                prepareToHydrateHostInstance
                    hydrateInstance
                        diffHydratedProperties
                            listenToNonDelegatedEvent


listenToNonDelegatedEvent | listenToNativeEvent
    addTrappedEventListener
        createEventListenerWrapperWithPriority
        addEventCaptureListenerWithPassiveFlag
        addEventCaptureListener
        addEventBubbleListenerWithPassiveFlag
        addEventBubbleListener



createEventListenerWrapperWithPriority
    dispatchDiscreteEvent | dispatchContinuousEvent
        dispatchEvent
            dispatchEventWithEnableCapturePhaseSelectiveHydrationWithoutDiscreteEventReplay
                dispatchEventForPluginEventSystem
                    batchedUpdates
                        batchedUpdatesImpl
                            dispatchEventsForPlugins
                                extractEvents$5
                                    extractEvents$2
                                    extractEvents$1
                                    extractEvents$3
                                    extractEvents


*/