/*
    ReactDOM.render is no longer supported in React 18. Use createRoot instead. 
    Until you switch to the new API, your app will behave as if it's running React 17. 
    Learn more: https://reactjs.org/link/switch-to-createroot
*/

const container = document.getElementById('root')
const elem = React.createElement('h1', null, 'Hello')

ReactDOM.render(
    elem,
    container
)

// const root = ReactDOM.createRoot(container)
// root.render(elem)
