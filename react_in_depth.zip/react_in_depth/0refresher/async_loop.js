function test1() {
    for (let i = 0; i < 5; i++) {
        console.log(i)
    }
}

function test1() {
    let i = 0
    function print() {
        console.log(i)
        i++
        if (i < 5) {
            print()
        }
    }
    print()
}

function test() {
    function print(i) {
        if (print.upperBound === undefined) {
            print.upperBound = i
        }
        console.log(print.upperBound - i)
        i--
        if (i > 0) {
            print(i)
        }
    }
    print(5)
}

function test1() {
    function print(upperBound) {
        let i = upperBound
        return function doPrint() {
            console.log(upperBound - i)
            i--
            if (i > 0) {
                doPrint()
            }
        }
    }
    print(5)()
}

function test() {
    let i = 0
    function print() {
        console.log(i)
        i++
        if (i < 5) {
            if (i === 3) debugger
            setTimeout(print, 1000)
        }
    }
    print()
}

test()
