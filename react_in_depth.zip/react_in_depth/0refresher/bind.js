
function test1() {
    function listenerWrapper(param1, param2, param3) {
        // console.log(arguments)
        console.log(param1, param2, param3)
    }
    const domEventName = 123
    const eventSystemFlags = 456
    const targetContainer = 789
    const listenerWrapperBound = listenerWrapper.bind(
        null, 
        domEventName, 
        eventSystemFlags, 
        targetContainer
    )
    listenerWrapperBound()
    listenerWrapperBound()
}

function test() {
    function listenerWrapper() {
        console.log(this)
    }
    const listenerWrapperBound = listenerWrapper.bind(
        {hello: 'world'},
    )
    listenerWrapperBound()
}

test()
