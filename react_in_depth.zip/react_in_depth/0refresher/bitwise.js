function test() {
    let byte = 0b0000_0000
    byte |= 16
    byte |= 2 | 4
    console.log(byte.toString(2)) // 10110
}

test()
