function test1() {
    let byte = 0b00000000
    byte |= 16
    console.log(byte.toString(2).padStart(8, '0')) // 00010000
    byte |= 2 | 4
    console.log(byte.toString(2).padStart(8, '0')) // 00010110
}

function test() {
    let byte = 0b00000000
    // byte |= 128 | 64 | 32 | 16
    // byte |= 240
    // byte |= 15 << 4
    console.log(byte.toString(2).padStart(8, '0')) // 11110000
    // byte |= 8 | 4 | 2 | 1
    // byte |= 255
    byte |= 0b100000000 - 1
    console.log(byte.toString(2).padStart(8, '0')) // 11111111
}

test()
