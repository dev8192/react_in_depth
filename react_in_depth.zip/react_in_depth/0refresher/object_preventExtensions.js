/*
Extensibility of objects
*/

function test() {
    'use strict'
    class Person {
        constructor(name, age) {
            this.name = name
            this.age = age
            Object.preventExtensions(this)
        }
    }
    const person = new Person('John', 23)
    person.occupation = 'programmer'
    console.log(person)
}

function test1() {
    class Person {
        constructor(name, age) {
            this.name = name
            this.age = age
            Object.preventExtensions(this)
        }
    }
    class Student extends Person {
        constructor(name, age, major) {
            super(name, age)
            this.major = major
        }
    }
    const student = new Student('John', 23, 'CS')
    console.log(student)
}

test()
