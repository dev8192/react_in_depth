'''
TODO: compare this with map_obj.js
'''

def test():
    dict1 = {
        'hello': 'world',
    }
    for item in dict1:
        print(item) # ['hello', 'world']
    for item in dict1.entries():
        print(item) # ['hello', 'world']
    for item in dict1.keys():
        print(item) # hello
    for item in dict1.values():
        print(item) # world

test()
