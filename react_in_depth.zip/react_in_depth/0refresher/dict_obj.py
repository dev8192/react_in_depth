
def test():
    dict1 = {
        'hello': 'world',
    }
    for item in dict1:
        print(item) # hello
    for item in dict1.items():
        print(item) # ('hello', 'world')
    for item in dict1.keys():
        print(item) # hello
    for item in dict1.values():
        print(item) # world

test()
