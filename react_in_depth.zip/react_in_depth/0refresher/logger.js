/*
    This program shows how changes to ReactCurrentBatchConfig.transition can be logged
*/

function test1() {
    var ReactCurrentBatchConfig = {
        transition: null
    }
    console.log(ReactCurrentBatchConfig.transition)
    ReactCurrentBatchConfig.transition = 'hello'
    console.log(ReactCurrentBatchConfig.transition)
    ReactCurrentBatchConfig.transition = 'world'
    console.log(ReactCurrentBatchConfig.transition)
}

function test() {
    var ReactCurrentBatchConfig = {
        _transition: null,
        set transition(value) {
            this._transition = value
        },
        get transition() {
            return this._transition
        }
    }
    console.log(ReactCurrentBatchConfig.transition)
    ReactCurrentBatchConfig.transition = 'hello'
    console.log(ReactCurrentBatchConfig.transition)
    ReactCurrentBatchConfig.transition = 'world'
    console.log(ReactCurrentBatchConfig.transition)
}

function test1() {
    var ReactCurrentBatchConfig = {
        _transition: null,
        set transition(value) {
            console.log(value)
            this._transition = value
        },
        get transition() {
            return this._transition
        }
    }
    console.log(ReactCurrentBatchConfig.transition)
    ReactCurrentBatchConfig.transition = 'hello'
    ReactCurrentBatchConfig.transition = 'world'
}

test()
