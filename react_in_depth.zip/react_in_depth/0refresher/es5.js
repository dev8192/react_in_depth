/*
What is the point of using return in SyntheticBaseEvent?
*/

function test() {
    function Person(name, age) {
        this.name = name
        this.age = age
        // return this
        // return {hello: 'world'}
    }
    const person = new Person('John', 33)
    console.log(person)
}

test()
