
function test1() {
    const map = new Map([
        ['one', '111'],
        ['two', '222'],
        ['three', '333'],
    ])
    console.log(map)
}

/*
Are there cleaner alternatives?
*/
function test1() {
    const map = new Map(Object.entries({
        one: 111,
        two: 222,
        three: 333,
    }))
    console.log(map)
}

function test() {
    const map = new Map([
        ['hello', 'world'],
    ])
    for (const item of map) {
        console.log(item) // ['hello', 'world']
    }
    for (const item of map.entries()) {
        console.log(item) // ['hello', 'world']
    }
    for (const item of map.keys()) {
        console.log(item) // hello
    }
    for (const item of map.values()) {
        console.log(item) // world
    }
}

test()
