
function listenerWrapper1() {
    console.log(arguments)
}
function listenerWrapper(param1, param2, param3) {
    console.log(param1, param2, param3)
}
const domEventName = 123
const eventSystemFlags = 456
const targetContainer = 789

function test1() {
    const listenerWrapperBound = listenerWrapper.bind(
        null, 
        domEventName, 
        eventSystemFlags, 
        targetContainer
    )
    listenerWrapperBound()
    listenerWrapperBound()
}

function test() {
    const listenerWrapperBound = listenerWrapper.bind(
        {hello: 'world'}, 
        domEventName, 
        eventSystemFlags, 
        targetContainer
    )
    listenerWrapperBound()
    listenerWrapperBound()
}

test()
