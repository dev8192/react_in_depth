const container = document.getElementById('root')
const elem = React.createElement('h1', null, 'Hello World!')
const root = ReactDOM.createRoot(container)
root.render(elem)
