const container = document.getElementById('root')
const elem = React.createElement(function() {
    return 'hello' // can i do this?
    return React.createElement(
        'div',
        null,
        'hello function'
    )
})
const root = ReactDOM.createRoot(container)
root.render(elem)
