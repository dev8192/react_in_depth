const container = document.getElementById('root')
const elem = React.createElement(
    React.Fragment,
    null,
    'hello fragment'
)
const root = ReactDOM.createRoot(container)
root.render(elem)
