/*
    <script src="event\createSyntheticEvent.js"></script>
    <script src="event\createSyntheticEvent.test.js"></script>
*/

function test1() {
    let reactName
    let reactEventType
    let targetInst
    let nativeEvent = {}
    let nativeEventTarget
    const event = new SyntheticEvent(reactName, reactEventType, targetInst, nativeEvent, nativeEventTarget)
    // console.log(event)
    
    // console.log(event.isDefaultPrevented())
    // event.preventDefault()
    // console.log(event.isDefaultPrevented())
    
    // console.log(event.isPropagationStopped())
    // event.stopPropagation()
    // console.log(event.isPropagationStopped())
}

function test1() {
    let reactName
    let reactEventType
    let targetInst
    let nativeEvent = {}
    let nativeEventTarget
    const event1 = new SyntheticEvent(reactName, reactEventType, targetInst, nativeEvent, nativeEventTarget)
    const event2 = new SyntheticEvent(reactName, reactEventType, targetInst, nativeEvent, nativeEventTarget)
    console.log(Object.getPrototypeOf(event1).constructor === Object.getPrototypeOf(event2).constructor)
    console.log(Object.getPrototypeOf(event1) === Object.getPrototypeOf(event2))
}

/*
All synthetic events
*/
function test1() {
    let event
    event = new SyntheticEvent(null, null, null, {})
    event = new SyntheticUIEvent(null, null, null, {})
    event = new SyntheticMouseEvent(null, null, null, {})
    event = new SyntheticDragEvent(null, null, null, {})
    event = new SyntheticPointerEvent(null, null, null, {})
    event = new SyntheticFocusEvent(null, null, null, {})
    event = new SyntheticTouchEvent(null, null, null, {})
    event = new SyntheticWheelEvent(null, null, null, {})
    event = new SyntheticAnimationEvent(null, null, null, {})
    event = new SyntheticClipboardEvent(null, null, null, {})
    event = new SyntheticCompositionEvent(null, null, null, {})
    event = new SyntheticKeyboardEvent(null, null, null, {})
    event = new SyntheticTransitionEvent(null, null, null, {})
}

function test1() {
    const event = new SyntheticKeyboardEvent(null, null, null, {
        key: 'hello',
    })
    console.log(event.key) // hello
}

function test1() {
    const event = new SyntheticKeyboardEvent(null, null, null, {
        key: 'Win',
    })
    console.log(event.key) // OS
}

function test1() {
    const event = new SyntheticKeyboardEvent(null, null, null, {
        type: 'keypress',
        charCode: 33,
    })
    console.log(event.key) // !
}

function test1() {
    const event = new SyntheticKeyboardEvent(null, null, null, {
        type: 'keydown',
        keyCode: 33,
    })
    console.log(event.key) // PageUp
}

function test1() {
    const event = new SyntheticKeyboardEvent(null, null, null, {
        getModifierState(keyArg) {
            return keyArg
        }
    })
    console.log(event.getModifierState('Hello'))
}

function test() {
    const event = new SyntheticKeyboardEvent(null, null, null, {
        altKey: true,
    })
    console.log(event.altKey)
    console.log(event.getModifierState('Alt'))
}

/*
TODO: Find all cases when event.key === 'Unidentified'
*/

test()
