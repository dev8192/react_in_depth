/*
    <script src="event\topLevelEvents.js"></script>
    <script src="event\extractEvents.js"></script>
    <script src="event\extractEvents.test.js"></script>
*/

/*
The simplest way to get an empty dispatchQueue
*/
function test1() {
    debugger
    var dispatchQueue = []
    var domEventName = 'hello'
    var targetInst
    var nativeEvent
    var nativeEventTarget
    var eventSystemFlags = SHOULD_NOT_PROCESS_POLYFILL_EVENT_PLUGINS
    extractEvents$5(
        dispatchQueue,
        domEventName,
        targetInst,
        nativeEvent,
        nativeEventTarget,
        eventSystemFlags,
    )
    console.log(dispatchQueue)
}

/*
Firefox creates a click event on right mouse clicks. (Does it really?)
This removes the unwanted click events.
*/
function test1() {
    debugger
    var dispatchQueue = []
    var domEventName = 'click'
    var targetInst
    var nativeEvent = {button: 2}
    var nativeEventTarget
    var eventSystemFlags = SHOULD_NOT_PROCESS_POLYFILL_EVENT_PLUGINS
    extractEvents$5(
        dispatchQueue,
        domEventName,
        targetInst,
        nativeEvent,
        nativeEventTarget,
        eventSystemFlags,
    )
    console.log(dispatchQueue)
}

/*
SyntheticInputEvent
*/
function test() {
    var dispatchQueue = []
    var domEventName = 'click'
    var targetInst // FiberNode
    var nativeEvent = {} // PointerEvent, etc
    var nativeEventTarget // button, etc
    var eventSystemFlags = 0
    // var eventSystemFlags = IS_CAPTURE_PHASE
    extractEvents$5(
        dispatchQueue,
        domEventName,
        targetInst,
        nativeEvent,
        nativeEventTarget,
        eventSystemFlags,
    )
    console.log(dispatchQueue)
}

/*
extractCompositionEvent

*/

test()
