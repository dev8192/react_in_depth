/*
There are 13 interfaces.

EventInterface                      2       SyntheticEvent
    UIEventInterface                3       SyntheticUIEvent
        MouseEventInterface         4       SyntheticMouseEvent
            DragEventInterface      5       SyntheticDragEvent
            PointerEventInterface  11       SyntheticPointerEvent
        FocusEventInterface         6       SyntheticFocusEvent
        TouchEventInterface        12       SyntheticTouchEvent
        WheelEventInterface        14       SyntheticWheelEvent
    AnimationEventInterface         7       SyntheticAnimationEvent
    ClipboardEventInterface         8       SyntheticClipboardEvent
    CompositionEventInterface       9       SyntheticCompositionEvent | SyntheticInputEvent
    KeyboardEventInterface         10       SyntheticKeyboardEvent
    TransitionEventInterface       13       SyntheticTransitionEvent
*/

var assign = Object.assign; // 886

function getEventCharCode(nativeEvent) {
    var charCode;
    var keyCode = nativeEvent.keyCode;
    if ('charCode' in nativeEvent) {
        charCode = nativeEvent.charCode;

        if (charCode === 0 && keyCode === 13) {
            charCode = 13;
        }
    } else {
        charCode = keyCode;
    }
    if (charCode === 10) {
        charCode = 13;
    }
    if (charCode >= 32 || charCode === 13) {
        return charCode;
    }
    return 0;
}

function functionThatReturnsTrue() { // 6823
    return true;
}
function functionThatReturnsFalse() { // 6827
    return false;
}

function createSyntheticEvent(Interface) { // 6833
    function SyntheticBaseEvent(reactName, reactEventType, targetInst, nativeEvent, nativeEventTarget) {
        this._reactName = reactName;
        this._targetInst = targetInst;
        this.type = reactEventType;
        this.nativeEvent = nativeEvent;
        this.target = nativeEventTarget;
        this.currentTarget = null;

        for (var _propName in Interface) {
            if (!Interface.hasOwnProperty(_propName)) {
                continue;
            }

            var normalize = Interface[_propName];

            if (normalize) {
                this[_propName] = normalize(nativeEvent);
            } else {
                this[_propName] = nativeEvent[_propName];
            }
        }

        var defaultPrevented = nativeEvent.defaultPrevented != null ? 
            nativeEvent.defaultPrevented : 
            nativeEvent.returnValue === false;

        if (defaultPrevented) {
            this.isDefaultPrevented = functionThatReturnsTrue;
        } else {
            this.isDefaultPrevented = functionThatReturnsFalse;
        }

        this.isPropagationStopped = functionThatReturnsFalse;
        return this;
    }

    assign(SyntheticBaseEvent.prototype, {
        preventDefault: function () {
            this.defaultPrevented = true;
            var event = this.nativeEvent;
            if (!event) {
                return;
            }
            if (event.preventDefault) {
                event.preventDefault();
            } else if (typeof event.returnValue !== 'unknown') {
                event.returnValue = false;
            }
            this.isDefaultPrevented = functionThatReturnsTrue;
        },
        stopPropagation: function () {
            var event = this.nativeEvent;
            if (!event) {
                return;
            }
            if (event.stopPropagation) {
                event.stopPropagation();
            } else if (typeof event.cancelBubble !== 'unknown') {
                event.cancelBubble = true;
            }
            this.isPropagationStopped = functionThatReturnsTrue;
        },
        persist: function () {
        },
        isPersistent: functionThatReturnsTrue
    });
    return SyntheticBaseEvent;
}

/****************************** EventInterface ******************************/

var EventInterface = {
    eventPhase: 0,
    bubbles: 0,
    cancelable: 0,
    timeStamp: function (event) {
        return event.timeStamp || Date.now();
    },
    defaultPrevented: 0,
    isTrusted: 0
};
var SyntheticEvent = createSyntheticEvent(EventInterface);

/****************************** UIEventInterface ******************************/

var UIEventInterface = assign({}, EventInterface, {
    view: 0,
    detail: 0
});
var SyntheticUIEvent = createSyntheticEvent(UIEventInterface);

/****************************** MouseEventInterface ******************************/

var lastMovementX;
var lastMovementY;
var lastMouseEvent;
function updateMouseMovementPolyfillState(event) {
    if (event !== lastMouseEvent) {
        if (lastMouseEvent && event.type === 'mousemove') {
            lastMovementX = event.screenX - lastMouseEvent.screenX;
            lastMovementY = event.screenY - lastMouseEvent.screenY;
        } else {
            lastMovementX = 0;
            lastMovementY = 0;
        }
        lastMouseEvent = event;
    }
}
var MouseEventInterface = assign({}, UIEventInterface, {
    screenX: 0,
    screenY: 0,
    clientX: 0,
    clientY: 0,
    pageX: 0,
    pageY: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    getModifierState: getEventModifierState,
    button: 0,
    buttons: 0,
    relatedTarget: function (event) {
        if (event.relatedTarget === undefined) return event.fromElement === event.srcElement ? 
            event.toElement : 
            event.fromElement;
        return event.relatedTarget;
    },
    movementX: function (event) {
        if ('movementX' in event) {
            return event.movementX;
        }
        updateMouseMovementPolyfillState(event);
        return lastMovementX;
    },
    movementY: function (event) {
        if ('movementY' in event) {
            return event.movementY;
        }
        return lastMovementY;
    }
});
var SyntheticMouseEvent = createSyntheticEvent(MouseEventInterface);

/****************************** DragEventInterface ******************************/

var DragEventInterface = assign({}, MouseEventInterface, {
    dataTransfer: 0
});
var SyntheticDragEvent = createSyntheticEvent(DragEventInterface);

/****************************** FocusEventInterface ******************************/

var FocusEventInterface = assign({}, UIEventInterface, {
    relatedTarget: 0
});
var SyntheticFocusEvent = createSyntheticEvent(FocusEventInterface);

/****************************** AnimationEventInterface ******************************/

var AnimationEventInterface = assign({}, EventInterface, {
    animationName: 0,
    elapsedTime: 0,
    pseudoElement: 0
});
var SyntheticAnimationEvent = createSyntheticEvent(AnimationEventInterface);

/****************************** ClipboardEventInterface ******************************/

var ClipboardEventInterface = assign({}, EventInterface, {
    clipboardData: function (event) {
        return 'clipboardData' in event ? event.clipboardData : window.clipboardData;
    }
});
var SyntheticClipboardEvent = createSyntheticEvent(ClipboardEventInterface);

/****************************** CompositionEventInterface ******************************/

var CompositionEventInterface = assign({}, EventInterface, {
    data: 0
});
var SyntheticCompositionEvent = createSyntheticEvent(CompositionEventInterface);
var SyntheticInputEvent = SyntheticCompositionEvent;

/****************************** KeyboardEventInterface ******************************/

var normalizeKey = {
    Esc: 'Escape',
    Spacebar: ' ',
    Left: 'ArrowLeft',
    Up: 'ArrowUp',
    Right: 'ArrowRight',
    Down: 'ArrowDown',
    Del: 'Delete',
    Win: 'OS',
    Menu: 'ContextMenu',
    Apps: 'ContextMenu',
    Scroll: 'ScrollLock',
    MozPrintableKey: 'Unidentified'
};
var translateToKey = {
    '8': 'Backspace',
    '9': 'Tab',
    '12': 'Clear',
    '13': 'Enter',
    '16': 'Shift',
    '17': 'Control',
    '18': 'Alt',
    '19': 'Pause',
    '20': 'CapsLock',
    '27': 'Escape',
    '32': ' ',
    '33': 'PageUp',
    '34': 'PageDown',
    '35': 'End',
    '36': 'Home',
    '37': 'ArrowLeft',
    '38': 'ArrowUp',
    '39': 'ArrowRight',
    '40': 'ArrowDown',
    '45': 'Insert',
    '46': 'Delete',
    '112': 'F1',
    '113': 'F2',
    '114': 'F3',
    '115': 'F4',
    '116': 'F5',
    '117': 'F6',
    '118': 'F7',
    '119': 'F8',
    '120': 'F9',
    '121': 'F10',
    '122': 'F11',
    '123': 'F12',
    '144': 'NumLock',
    '145': 'ScrollLock',
    '224': 'Meta'
};
function getEventKey(nativeEvent) {
    if (nativeEvent.key) {
        var key = normalizeKey[nativeEvent.key] || nativeEvent.key;
        if (key !== 'Unidentified') {
            return key;
        }
    }
    if (nativeEvent.type === 'keypress') {
        var charCode = getEventCharCode(nativeEvent);
        return charCode === 13 ? 'Enter' : String.fromCharCode(charCode);
    }
    if (nativeEvent.type === 'keydown' || nativeEvent.type === 'keyup') {
        return translateToKey[nativeEvent.keyCode] || 'Unidentified';
    }
    return '';
}
var modifierKeyToProp = {
    Alt: 'altKey',
    Control: 'ctrlKey',
    Meta: 'metaKey',
    Shift: 'shiftKey'
};
function modifierStateGetter(keyArg) {
    // debugger
    var syntheticEvent = this;
    var nativeEvent = syntheticEvent.nativeEvent;
    if (nativeEvent.getModifierState) {
        return nativeEvent.getModifierState(keyArg);
    }
    var keyProp = modifierKeyToProp[keyArg];
    return keyProp ? !!nativeEvent[keyProp] : false;
}
function getEventModifierState(nativeEvent) { // why do we need this wrapper?
    return modifierStateGetter;
}
var KeyboardEventInterface = assign({}, UIEventInterface, {
    key: getEventKey,
    code: 0,
    location: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    repeat: 0,
    locale: 0,
    getModifierState: getEventModifierState,
    charCode: function (event) {
        if (event.type === 'keypress') {
            return getEventCharCode(event);
        }
        return 0;
    },
    keyCode: function (event) {
        if (event.type === 'keydown' || event.type === 'keyup') {
            return event.keyCode;
        }
        return 0;
    },
    which: function (event) {
        if (event.type === 'keypress') {
            return getEventCharCode(event);
        }
        if (event.type === 'keydown' || event.type === 'keyup') {
            return event.keyCode;
        }
        return 0;
    }
});
var SyntheticKeyboardEvent = createSyntheticEvent(KeyboardEventInterface);

/****************************** PointerEventInterface ******************************/

var PointerEventInterface = assign({}, MouseEventInterface, {
    pointerId: 0,
    width: 0,
    height: 0,
    pressure: 0,
    tangentialPressure: 0,
    tiltX: 0,
    tiltY: 0,
    twist: 0,
    pointerType: 0,
    isPrimary: 0
});
var SyntheticPointerEvent = createSyntheticEvent(PointerEventInterface);

/****************************** TouchEventInterface ******************************/

var TouchEventInterface = assign({}, UIEventInterface, {
    touches: 0,
    targetTouches: 0,
    changedTouches: 0,
    altKey: 0,
    metaKey: 0,
    ctrlKey: 0,
    shiftKey: 0,
    getModifierState: getEventModifierState
});
var SyntheticTouchEvent = createSyntheticEvent(TouchEventInterface);

/****************************** TransitionEventInterface ******************************/

var TransitionEventInterface = assign({}, EventInterface, {
    propertyName: 0,
    elapsedTime: 0,
    pseudoElement: 0
});
var SyntheticTransitionEvent = createSyntheticEvent(TransitionEventInterface);

/****************************** WheelEventInterface ******************************/

var WheelEventInterface = assign({}, MouseEventInterface, {
    deltaX: function (event) {
        return 'deltaX' in event ? event.deltaX :
            'wheelDeltaX' in event ? -event.wheelDeltaX : 0;
    },
    deltaY: function (event) {
        return 'deltaY' in event ? event.deltaY :
            'wheelDeltaY' in event ? -event.wheelDeltaY :
                'wheelDelta' in event ? -event.wheelDelta : 0;
    },
    deltaZ: 0,
    deltaMode: 0
});
var SyntheticWheelEvent = createSyntheticEvent(WheelEventInterface);
