
var registrationNameDependencies = {}

var possibleRegistrationNames = {}

const eventRegistry = {
    registrationNameDependencies: registrationNameDependencies,
    possibleRegistrationNames: possibleRegistrationNames
}
