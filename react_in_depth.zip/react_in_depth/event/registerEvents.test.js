/*
    <script src="event\allNativeEvents.js"></script>
    <script src="event\registerEvents.js"></script>
    <script src="event\registerEvents.test.js"></script>
*/

function compareSets(set1, set2) {
    if (set1.size !== set2.size) {
        return false
    }
    for (const key of set1) {
        if (!set2.has(key)) {
            return false
        }
    }
    return true
}
const allNativeEventsExpected = getAllNativeEvents()
console.log(compareSets(allNativeEvents, allNativeEventsExpected))
