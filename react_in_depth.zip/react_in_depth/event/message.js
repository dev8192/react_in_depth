/*
TODO: What about the 'message' event?
It is not included in the 'allNativeEvents' set,
yet it has a very special treatment in getEventPriority()

*/