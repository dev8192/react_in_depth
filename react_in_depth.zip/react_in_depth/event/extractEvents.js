/*
These functions are responsible for populating dispatchQueue.
Empty dispatchQueue means that no events are dispatched.
*/

var IS_EVENT_HANDLE_NON_MANAGED_NODE = 1; // 3818
var IS_NON_DELEGATED = 1 << 1;
var IS_CAPTURE_PHASE = 1 << 2;
var SHOULD_NOT_PROCESS_POLYFILL_EVENT_PLUGINS = IS_EVENT_HANDLE_NON_MANAGED_NODE | IS_NON_DELEGATED | IS_CAPTURE_PHASE;

function extractCompositionEvent(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget) { // 7478
    var eventType;
    var fallbackData;

    if (canUseCompositionEvent) {
        eventType = getCompositionEventType(domEventName);
    } else if (!isComposing) {
        if (isFallbackCompositionStart(domEventName, nativeEvent)) {
            eventType = 'onCompositionStart';
        }
    } else if (isFallbackCompositionEnd(domEventName, nativeEvent)) {
        eventType = 'onCompositionEnd';
    }

    if (!eventType) {
        return null;
    }

    if (useFallbackCompositionData && !isUsingKoreanIME(nativeEvent)) {
        // The current composition is stored statically and must not be
        // overwritten while composition continues.
        if (!isComposing && eventType === 'onCompositionStart') {
            isComposing = initialize(nativeEventTarget);
        } else if (eventType === 'onCompositionEnd') {
            if (isComposing) {
                fallbackData = getData();
            }
        }
    }

    var listeners = accumulateTwoPhaseListeners(targetInst, eventType);

    if (listeners.length > 0) {
        var event = new SyntheticCompositionEvent(eventType, domEventName, null, nativeEvent, nativeEventTarget);
        dispatchQueue.push({
            event: event,
            listeners: listeners
        });

        if (fallbackData) {
            // Inject data generated from fallback path into the synthetic event.
            // This matches the property of native CompositionEventInterface.
            event.data = fallbackData;
        } else {
            var customData = getDataFromCustomEvent(nativeEvent);

            if (customData !== null) {
                event.data = customData;
            }
        }
    }
}


function extractBeforeInputEvent(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget) { // 7653
    var chars;
    if (canUseTextInputEvent) {
        chars = getNativeBeforeInputChars(domEventName, nativeEvent);
    } else {
        chars = getFallbackBeforeInputChars(domEventName, nativeEvent);
    }
    if (!chars) {
        return null;
    }
    var listeners = accumulateTwoPhaseListeners(targetInst, 'onBeforeInput');
    if (listeners.length > 0) {
        var event = new SyntheticInputEvent('onBeforeInput', 'beforeinput', null, nativeEvent, nativeEventTarget);
        dispatchQueue.push({
            event: event,
            listeners: listeners
        });
        event.data = chars;
    }
}

function extractEvents(
    dispatchQueue,
    domEventName,
    targetInst,
    nativeEvent,
    nativeEventTarget,
) { // 7699
    extractCompositionEvent(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget);
    extractBeforeInputEvent(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget);
}

function extractEvents$1(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget) { // 7976
    var targetNode = targetInst ? getNodeFromInstance(targetInst) : window;
    var getTargetInstFunc, handleEventFunc;

    if (shouldUseChangeEvent(targetNode)) {
        getTargetInstFunc = getTargetInstForChangeEvent;
    } else if (isTextInputElement(targetNode)) {
        if (isInputEventSupported) {
            getTargetInstFunc = getTargetInstForInputOrChangeEvent;
        } else {
            getTargetInstFunc = getTargetInstForInputEventPolyfill;
            handleEventFunc = handleEventsForInputEventPolyfill;
        }
    } else if (shouldUseClickEvent(targetNode)) {
        getTargetInstFunc = getTargetInstForClickEvent;
    }

    if (getTargetInstFunc) {
        var inst = getTargetInstFunc(domEventName, targetInst);

        if (inst) {
            createAndAccumulateChangeEvent(dispatchQueue, inst, nativeEvent, nativeEventTarget);
            return;
        }
    }

    if (handleEventFunc) {
        handleEventFunc(domEventName, targetNode, targetInst);
    } // When blurring, set the value attribute for number inputs


    if (domEventName === 'focusout') {
        handleControlledInputBlur(targetNode);
    }
}

function extractEvents$2(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget) { // 8027
    var isOverEvent = domEventName === 'mouseover' || domEventName === 'pointerover';
    var isOutEvent = domEventName === 'mouseout' || domEventName === 'pointerout';

    if (isOverEvent && !isReplayingEvent(nativeEvent)) {
        // If this is an over event with a target, we might have already dispatched
        // the event in the out event of the other target. If this is replayed,
        // then it's because we couldn't dispatch against this target previously
        // so we have to do it now instead.
        var related = nativeEvent.relatedTarget || nativeEvent.fromElement;

        if (related) {
            // If the related node is managed by React, we can assume that we have
            // already dispatched the corresponding events during its mouseout.
            if (getClosestInstanceFromNode(related) || isContainerMarkedAsRoot(related)) {
                return;
            }
        }
    }

    if (!isOutEvent && !isOverEvent) {
        // Must not be a mouse or pointer in or out - ignoring.
        return;
    }

    var win; // TODO: why is this nullable in the types but we read from it?

    if (nativeEventTarget.window === nativeEventTarget) {
        // `nativeEventTarget` is probably a window object.
        win = nativeEventTarget;
    } else {
        // TODO: Figure out why `ownerDocument` is sometimes undefined in IE8.
        var doc = nativeEventTarget.ownerDocument;

        if (doc) {
            win = doc.defaultView || doc.parentWindow;
        } else {
            win = window;
        }
    }

    var from;
    var to;

    if (isOutEvent) {
        var _related = nativeEvent.relatedTarget || nativeEvent.toElement;

        from = targetInst;
        to = _related ? getClosestInstanceFromNode(_related) : null;

        if (to !== null) {
            var nearestMounted = getNearestMountedFiber(to);

            if (to !== nearestMounted || to.tag !== HostComponent && to.tag !== HostText) {
                to = null;
            }
        }
    } else {
        // Moving to a node from outside the window.
        from = null;
        to = targetInst;
    }

    if (from === to) {
        // Nothing pertains to our managed components.
        return;
    }

    var SyntheticEventCtor = SyntheticMouseEvent;
    var leaveEventType = 'onMouseLeave';
    var enterEventType = 'onMouseEnter';
    var eventTypePrefix = 'mouse';

    if (domEventName === 'pointerout' || domEventName === 'pointerover') {
        SyntheticEventCtor = SyntheticPointerEvent;
        leaveEventType = 'onPointerLeave';
        enterEventType = 'onPointerEnter';
        eventTypePrefix = 'pointer';
    }

    var fromNode = from == null ? win : getNodeFromInstance(from);
    var toNode = to == null ? win : getNodeFromInstance(to);
    var leave = new SyntheticEventCtor(leaveEventType, eventTypePrefix + 'leave', from, nativeEvent, nativeEventTarget);
    leave.target = fromNode;
    leave.relatedTarget = toNode;
    var enter = null; // We should only process this nativeEvent if we are processing
    // the first ancestor. Next time, we will ignore the event.

    var nativeTargetInst = getClosestInstanceFromNode(nativeEventTarget);

    if (nativeTargetInst === targetInst) {
        var enterEvent = new SyntheticEventCtor(enterEventType, eventTypePrefix + 'enter', to, nativeEvent, nativeEventTarget);
        enterEvent.target = toNode;
        enterEvent.relatedTarget = fromNode;
        enter = enterEvent;
    }

    accumulateEnterLeaveTwoPhaseListeners(dispatchQueue, leave, enter, from, to);
}

function extractEvents$3(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget) { // 8680
    var targetNode = targetInst ? getNodeFromInstance(targetInst) : window;

    switch (domEventName) {
        // Track the input node that has focus.
        case 'focusin':
            if (isTextInputElement(targetNode) || targetNode.contentEditable === 'true') {
                activeElement$1 = targetNode;
                activeElementInst$1 = targetInst;
                lastSelection = null;
            }

            break;

        case 'focusout':
            activeElement$1 = null;
            activeElementInst$1 = null;
            lastSelection = null;
            break;
        // Don't fire the event while the user is dragging. This matches the
        // semantics of the native select event.

        case 'mousedown':
            mouseDown = true;
            break;

        case 'contextmenu':
        case 'mouseup':
        case 'dragend':
            mouseDown = false;
            constructSelectEvent(dispatchQueue, nativeEvent, nativeEventTarget);
            break;
        // Chrome and IE fire non-standard event when selection is changed (and
        // sometimes when it hasn't). IE's event fires out of order with respect
        // to key and input events on deletion, so we discard it.
        //
        // Firefox doesn't support selectionchange, so check selection status
        // after each key entry. The selection changes after keydown and before
        // keyup, but we check on keydown as well in the case of holding down a
        // key, when multiple keydown events are fired but only one keyup is.
        // This is also our approach for IE handling, for the reason above.

        case 'selectionchange':
            if (skipSelectionChangeEvent) {
                break;
            }

        // falls through

        case 'keydown':
        case 'keyup':
            constructSelectEvent(dispatchQueue, nativeEvent, nativeEventTarget);
    }
}

function extractEvents$4(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget, eventSystemFlags, targetContainer) { // 8858
    var reactName = topLevelEventsToReactNames.get(domEventName);

    if (reactName === undefined) {
        return;
    }

    var SyntheticEventCtor = SyntheticEvent;
    var reactEventType = domEventName;

    switch (domEventName) {
        case 'keypress':
            if (getEventCharCode(nativeEvent) === 0) {
                return;
            }
        case 'keydown':
        case 'keyup':
            SyntheticEventCtor = SyntheticKeyboardEvent;
            break;

        case 'focusin':
            reactEventType = 'focus';
            SyntheticEventCtor = SyntheticFocusEvent;
            break;

        case 'focusout':
            reactEventType = 'blur';
            SyntheticEventCtor = SyntheticFocusEvent;
            break;

        case 'beforeblur':
        case 'afterblur':
            SyntheticEventCtor = SyntheticFocusEvent;
            break;

        case 'click':
            // Firefox creates a click event on right mouse clicks. This removes the
            // unwanted click events.
            if (nativeEvent.button === 2) {
                return;
            }

        /* falls through */

        case 'auxclick':
        case 'dblclick':
        case 'mousedown':
        case 'mousemove':
        case 'mouseup': // TODO: Disabled elements should not respond to mouse events

        /* falls through */

        case 'mouseout':
        case 'mouseover':
        case 'contextmenu':
            SyntheticEventCtor = SyntheticMouseEvent;
            break;

        case 'drag':
        case 'dragend':
        case 'dragenter':
        case 'dragexit':
        case 'dragleave':
        case 'dragover':
        case 'dragstart':
        case 'drop':
            SyntheticEventCtor = SyntheticDragEvent;
            break;

        case 'touchcancel':
        case 'touchend':
        case 'touchmove':
        case 'touchstart':
            SyntheticEventCtor = SyntheticTouchEvent;
            break;

        case ANIMATION_END:
        case ANIMATION_ITERATION:
        case ANIMATION_START:
            SyntheticEventCtor = SyntheticAnimationEvent;
            break;

        case TRANSITION_END:
            SyntheticEventCtor = SyntheticTransitionEvent;
            break;

        case 'scroll':
            SyntheticEventCtor = SyntheticUIEvent;
            break;

        case 'wheel':
            SyntheticEventCtor = SyntheticWheelEvent;
            break;

        case 'copy':
        case 'cut':
        case 'paste':
            SyntheticEventCtor = SyntheticClipboardEvent;
            break;

        case 'gotpointercapture':
        case 'lostpointercapture':
        case 'pointercancel':
        case 'pointerdown':
        case 'pointermove':
        case 'pointerout':
        case 'pointerover':
        case 'pointerup':
            SyntheticEventCtor = SyntheticPointerEvent;
            break;
    }

    var inCapturePhase = (eventSystemFlags & IS_CAPTURE_PHASE) !== 0;

    {
        // Some events don't bubble in the browser.
        // In the past, React has always bubbled them, but this can be surprising.
        // We're going to try aligning closer to the browser behavior by not bubbling
        // them in React either. We'll start by not bubbling onScroll, and then expand.
        var accumulateTargetOnly = !inCapturePhase && // TODO: ideally, we'd eventually add all events from
            // nonDelegatedEvents list in DOMPluginEventSystem.
            // Then we can remove this special list.
            // This is a breaking change that can wait until React 18.
            domEventName === 'scroll';

        var _listeners = accumulateSinglePhaseListeners(targetInst, reactName, nativeEvent.type, inCapturePhase, accumulateTargetOnly);

        if (_listeners.length > 0) {
            // Intentionally create event lazily.
            var _event = new SyntheticEventCtor(reactName, reactEventType, null, nativeEvent, nativeEventTarget);

            dispatchQueue.push({
                event: _event,
                listeners: _listeners
            });
        }
    }
}

function extractEvents$5(
    dispatchQueue,
    domEventName,
    targetInst,
    nativeEvent,
    nativeEventTarget,
    eventSystemFlags
) { // 9010
    extractEvents$4(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget, eventSystemFlags)
    var shouldProcessPolyfillPlugins = (eventSystemFlags & SHOULD_NOT_PROCESS_POLYFILL_EVENT_PLUGINS) === 0
    if (shouldProcessPolyfillPlugins) {
        extractEvents$2(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget);
        extractEvents$1(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget);
        extractEvents$3(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget);
        extractEvents(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget);
    }
}

// entry point
function test() {
    var dispatchQueue = []
    var domEventName = 'click'
    var targetInst // FiberNode
    var nativeEvent // PointerEvent, etc
    var nativeEventTarget // button, etc
    var eventSystemFlags = 0
    // var eventSystemFlags = IS_CAPTURE_PHASE
    extractEvents$5(
        dispatchQueue,
        domEventName,
        targetInst,
        nativeEvent,
        nativeEventTarget,
        eventSystemFlags,
    )
    console.log(dispatchQueue)
}

test()
