/*
These functions are responsible for populating dispatchQueue.
Empty dispatchQueue means that no events are dispatched.
*/

/*********************************** mocks ***********************************/

// 12 synthetic events
function SyntheticEvent() {}
function SyntheticKeyboardEvent() {}
function SyntheticFocusEvent() {}
function SyntheticMouseEvent() {}
function SyntheticDragEvent() {}
function SyntheticTouchEvent() {}
function SyntheticAnimationEvent() {}
function SyntheticTransitionEvent() {}
function SyntheticUIEvent() {}
function SyntheticWheelEvent() {}
function SyntheticClipboardEvent() {}
function SyntheticPointerEvent() {}
function SyntheticCompositionEvent() {}
function SyntheticInputEvent() {}

function accumulateSinglePhaseListeners() {
    return [1]
}
function accumulateTwoPhaseListeners() {
    return [1]
}
function shouldUseChangeEvent() {}
function isTextInputElement() {}
function shouldUseClickEvent() {}
var canUseCompositionEvent
var isComposing
function isFallbackCompositionStart() {}
var canUseTextInputEvent
function getNativeBeforeInputChars() {}
function getFallbackBeforeInputChars() {
    return true
}
function getEventCharCode() {}
var ANIMATION_END
var ANIMATION_ITERATION
var ANIMATION_START
var TRANSITION_END

/*********************************** react-dom ***********************************/

var IS_EVENT_HANDLE_NON_MANAGED_NODE = 1; // 3818
var IS_NON_DELEGATED = 1 << 1;
var IS_CAPTURE_PHASE = 1 << 2;
var SHOULD_NOT_PROCESS_POLYFILL_EVENT_PLUGINS = IS_EVENT_HANDLE_NON_MANAGED_NODE | IS_NON_DELEGATED | IS_CAPTURE_PHASE;

function extractCompositionEvent(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget) { // 7478
    var eventType;
    var fallbackData;
    if (canUseCompositionEvent) {
        eventType = getCompositionEventType(domEventName);
    } else if (!isComposing) {
        if (isFallbackCompositionStart(domEventName, nativeEvent)) {
            eventType = 'onCompositionStart';
        }
    } else if (isFallbackCompositionEnd(domEventName, nativeEvent)) {
        eventType = 'onCompositionEnd';
    }
    if (!eventType) {
        return null;
    }
    if (useFallbackCompositionData && !isUsingKoreanIME(nativeEvent)) {
        if (!isComposing && eventType === 'onCompositionStart') {
            isComposing = initialize(nativeEventTarget);
        } else if (eventType === 'onCompositionEnd') {
            if (isComposing) {
                fallbackData = getData();
            }
        }
    }
    var listeners = accumulateTwoPhaseListeners(targetInst, eventType);
    if (listeners.length > 0) {
        var event = new SyntheticCompositionEvent(
            eventType, domEventName, null, nativeEvent, nativeEventTarget);
        dispatchQueue.push({
            event: event,
            listeners: listeners
        });
        if (fallbackData) {
            event.data = fallbackData;
        } else {
            var customData = getDataFromCustomEvent(nativeEvent);
            if (customData !== null) {
                event.data = customData;
            }
        }
    }
}

function extractBeforeInputEvent(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget) { // 7653
    var chars;
    if (canUseTextInputEvent) {
        chars = getNativeBeforeInputChars(domEventName, nativeEvent);
    } else {
        chars = getFallbackBeforeInputChars(domEventName, nativeEvent);
    }
    if (!chars) {
        return null;
    }
    var listeners = accumulateTwoPhaseListeners(targetInst, 'onBeforeInput');
    if (listeners.length > 0) {
        var event = new SyntheticInputEvent('onBeforeInput', 'beforeinput', null, nativeEvent, nativeEventTarget);
        dispatchQueue.push({
            event: event,
            listeners: listeners
        });
        event.data = chars;
    }
}

function extractEvents(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget) { // 7699
    extractCompositionEvent(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget);
    extractBeforeInputEvent(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget);
}

function extractEvents$1(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget) { // 7976
    var targetNode = targetInst ? getNodeFromInstance(targetInst) : window;
    var getTargetInstFunc, handleEventFunc;
    if (shouldUseChangeEvent(targetNode)) {
        getTargetInstFunc = getTargetInstForChangeEvent;
    } else if (isTextInputElement(targetNode)) {
        if (isInputEventSupported) {
            getTargetInstFunc = getTargetInstForInputOrChangeEvent;
        } else {
            getTargetInstFunc = getTargetInstForInputEventPolyfill;
            handleEventFunc = handleEventsForInputEventPolyfill;
        }
    } else if (shouldUseClickEvent(targetNode)) {
        getTargetInstFunc = getTargetInstForClickEvent;
    }
    if (getTargetInstFunc) {
        var inst = getTargetInstFunc(domEventName, targetInst);

        if (inst) {
            createAndAccumulateChangeEvent(dispatchQueue, inst, nativeEvent, nativeEventTarget);
            return;
        }
    }
    if (handleEventFunc) {
        handleEventFunc(domEventName, targetNode, targetInst);
    }
    if (domEventName === 'focusout') {
        handleControlledInputBlur(targetNode);
    }
}

function extractEvents$2(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget) { // 8027
    var isOverEvent = domEventName === 'mouseover' || domEventName === 'pointerover';
    var isOutEvent = domEventName === 'mouseout' || domEventName === 'pointerout';
    if (isOverEvent && !isReplayingEvent(nativeEvent)) {
        var related = nativeEvent.relatedTarget || nativeEvent.fromElement;
        if (related) {
            if (getClosestInstanceFromNode(related) || isContainerMarkedAsRoot(related)) {
                return;
            }
        }
    }
    if (!isOutEvent && !isOverEvent) {
        return;
    }
    var win;
    if (nativeEventTarget.window === nativeEventTarget) {
        win = nativeEventTarget;
    } else {
        var doc = nativeEventTarget.ownerDocument;
        if (doc) {
            win = doc.defaultView || doc.parentWindow;
        } else {
            win = window;
        }
    }
    var from;
    var to;
    if (isOutEvent) {
        var _related = nativeEvent.relatedTarget || nativeEvent.toElement;
        from = targetInst;
        to = _related ? getClosestInstanceFromNode(_related) : null;
        if (to !== null) {
            var nearestMounted = getNearestMountedFiber(to);
            if (to !== nearestMounted || to.tag !== HostComponent && to.tag !== HostText) {
                to = null;
            }
        }
    } else {
        from = null;
        to = targetInst;
    }
    if (from === to) {
        return;
    }
    var SyntheticEventCtor = SyntheticMouseEvent;
    var leaveEventType = 'onMouseLeave';
    var enterEventType = 'onMouseEnter';
    var eventTypePrefix = 'mouse';
    if (domEventName === 'pointerout' || domEventName === 'pointerover') {
        SyntheticEventCtor = SyntheticPointerEvent;
        leaveEventType = 'onPointerLeave';
        enterEventType = 'onPointerEnter';
        eventTypePrefix = 'pointer';
    }
    var fromNode = from == null ? win : getNodeFromInstance(from);
    var toNode = to == null ? win : getNodeFromInstance(to);
    var leave = new SyntheticEventCtor(
        leaveEventType, eventTypePrefix + 'leave', from, nativeEvent, nativeEventTarget);
    leave.target = fromNode;
    leave.relatedTarget = toNode;
    var enter = null;
    var nativeTargetInst = getClosestInstanceFromNode(nativeEventTarget);
    if (nativeTargetInst === targetInst) {
        var enterEvent = new SyntheticEventCtor(
            enterEventType,
            eventTypePrefix + 'enter',
            to,
            nativeEvent,
            nativeEventTarget
        );
        enterEvent.target = toNode;
        enterEvent.relatedTarget = fromNode;
        enter = enterEvent;
    }
    accumulateEnterLeaveTwoPhaseListeners(dispatchQueue, leave, enter, from, to);
}

function extractEvents$3(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget) { // 8680
    var targetNode = targetInst ? getNodeFromInstance(targetInst) : window;
    switch (domEventName) {
        case 'focusin':
            if (isTextInputElement(targetNode) || targetNode.contentEditable === 'true') {
                activeElement$1 = targetNode;
                activeElementInst$1 = targetInst;
                lastSelection = null;
            }
            break;
        case 'focusout':
            activeElement$1 = null;
            activeElementInst$1 = null;
            lastSelection = null;
            break;
        case 'mousedown':
            mouseDown = true;
            break;
        case 'contextmenu':
        case 'mouseup':
        case 'dragend':
            mouseDown = false;
            constructSelectEvent(dispatchQueue, nativeEvent, nativeEventTarget);
            break;
        case 'selectionchange':
            if (skipSelectionChangeEvent) {
                break;
            }
        case 'keydown':
        case 'keyup':
            constructSelectEvent(dispatchQueue, nativeEvent, nativeEventTarget);
    }
}

var topLevelEventsToReactNames = getTopLevelEventsToReactNames() // 8823

function extractEvents$4(
    dispatchQueue,
    domEventName,
    targetInst,
    nativeEvent,
    nativeEventTarget,
    eventSystemFlags
) { // 8858
    var reactName = topLevelEventsToReactNames.get(domEventName);
    if (reactName === undefined) {
        return;
    }
    var SyntheticEventCtor = SyntheticEvent;
    var reactEventType = domEventName;
    switch (domEventName) {
        case 'keypress':
            if (getEventCharCode(nativeEvent) === 0) {
                return;
            }
        case 'keydown':
        case 'keyup':
            SyntheticEventCtor = SyntheticKeyboardEvent;
            break;
        case 'focusin':
            reactEventType = 'focus';
            SyntheticEventCtor = SyntheticFocusEvent;
            break;
        case 'focusout':
            reactEventType = 'blur';
            SyntheticEventCtor = SyntheticFocusEvent;
            break;
        case 'beforeblur':
        case 'afterblur':
            SyntheticEventCtor = SyntheticFocusEvent;
            break;
        case 'click':
            if (nativeEvent.button === 2) {
                return;
            }
        case 'auxclick':
        case 'dblclick':
        case 'mousedown':
        case 'mousemove':
        case 'mouseup':
        case 'mouseout':
        case 'mouseover':
        case 'contextmenu':
            SyntheticEventCtor = SyntheticMouseEvent;
            break;
        case 'drag':
        case 'dragend':
        case 'dragenter':
        case 'dragexit':
        case 'dragleave':
        case 'dragover':
        case 'dragstart':
        case 'drop':
            SyntheticEventCtor = SyntheticDragEvent;
            break;
        case 'touchcancel':
        case 'touchend':
        case 'touchmove':
        case 'touchstart':
            SyntheticEventCtor = SyntheticTouchEvent;
            break;
        case ANIMATION_END:
        case ANIMATION_ITERATION:
        case ANIMATION_START:
            SyntheticEventCtor = SyntheticAnimationEvent;
            break;
        case TRANSITION_END:
            SyntheticEventCtor = SyntheticTransitionEvent;
            break;
        case 'scroll':
            SyntheticEventCtor = SyntheticUIEvent;
            break;
        case 'wheel':
            SyntheticEventCtor = SyntheticWheelEvent;
            break;
        case 'copy':
        case 'cut':
        case 'paste':
            SyntheticEventCtor = SyntheticClipboardEvent;
            break;
        case 'gotpointercapture':
        case 'lostpointercapture':
        case 'pointercancel':
        case 'pointerdown':
        case 'pointermove':
        case 'pointerout':
        case 'pointerover':
        case 'pointerup':
            SyntheticEventCtor = SyntheticPointerEvent;
            break;
    }
    var inCapturePhase = (eventSystemFlags & IS_CAPTURE_PHASE) !== 0;
    var accumulateTargetOnly = !inCapturePhase && domEventName === 'scroll';
    var _listeners = accumulateSinglePhaseListeners(
        targetInst, reactName, nativeEvent.type, inCapturePhase, accumulateTargetOnly);
    if (_listeners.length > 0) {
        var _event = new SyntheticEventCtor(reactName, reactEventType, null, nativeEvent, nativeEventTarget);
        dispatchQueue.push({
            event: _event,
            listeners: _listeners
        });
    }
}

function extractEvents$5(
    dispatchQueue,
    domEventName,
    targetInst,
    nativeEvent,
    nativeEventTarget,
    eventSystemFlags
) { // 9010
    extractEvents$4(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget, eventSystemFlags)
    var shouldProcessPolyfillPlugins = (eventSystemFlags & SHOULD_NOT_PROCESS_POLYFILL_EVENT_PLUGINS) === 0
    if (shouldProcessPolyfillPlugins) {
        extractEvents$2(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget);
        extractEvents$1(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget);
        extractEvents$3(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget);
        extractEvents(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget);
    }
}
