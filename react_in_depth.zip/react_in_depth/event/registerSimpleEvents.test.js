/*
    <script src="event\topLevelEvents.js"></script>
    <script src="event\registerSimpleEvents.js"></script>
    <script src="event\registerSimpleEvents.test.js"></script>
*/

const topLevelEventsToReactNamesExpected = getTopLevelEventsToReactNames()
topLevelEventsToReactNamesExpected.set('hello','world')
topLevelEventsToReactNames.set('Hello','world')

function compareMaps(map1, map2) {
    if (map1.size !== map2.size) {
        console.log('map1.size !== map2.size', map1.size, map2.size)
        return false
    }
    for (const [key, val] of map1.entries()) {
        if(map2.get(key) === undefined) {
            console.log('key not found:', key)
            return false
        }
        if(val !== map2.get(key)) {
            console.log(key, val, map2.get(key))
            return false
        }
    }
    return true
}

console.log(compareMaps(topLevelEventsToReactNames, topLevelEventsToReactNamesExpected))
