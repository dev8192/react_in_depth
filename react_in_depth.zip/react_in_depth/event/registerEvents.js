/*
This program shows how the allNativeEvents set is populated with events
*/
debugger
var allNativeEvents = new Set() // 145

function registerTwoPhaseEvent(registrationName, dependencies) { // 161
    registerDirectEvent(registrationName, dependencies);
    registerDirectEvent(registrationName + 'Capture', dependencies);
}
function registerDirectEvent(registrationName, dependencies) {
    for (var i = 0; i < dependencies.length; i++) {
        allNativeEvents.add(dependencies[i]);
    }
}

function registerEvents() { // 7365
    registerTwoPhaseEvent('onBeforeInput', 
        ['compositionend', 'keypress', 'textInput', 'paste']
    );
    registerTwoPhaseEvent('onCompositionEnd', 
        ['compositionend', 'focusout', 'keydown', 'keypress', 'keyup', 'mousedown']
    );
    registerTwoPhaseEvent('onCompositionStart', 
        ['compositionstart', 'focusout', 'keydown', 'keypress', 'keyup', 'mousedown']
    );
    registerTwoPhaseEvent('onCompositionUpdate', 
        ['compositionupdate', 'focusout', 'keydown', 'keypress', 'keyup', 'mousedown']
    );
}

function registerEvents$1() { // 7770
    registerTwoPhaseEvent('onChange', 
        [
            'change', 'click', 'focusin', 'focusout', 
            'input', 'keydown', 'keyup', 'selectionchange'
        ]
    );
}

function registerEvents$2() { // 8012
    registerDirectEvent('onMouseEnter', ['mouseout', 'mouseover']);
    registerDirectEvent('onMouseLeave', ['mouseout', 'mouseover']);
    registerDirectEvent('onPointerEnter', ['pointerout', 'pointerover']);
    registerDirectEvent('onPointerLeave', ['pointerout', 'pointerover']);
}

function registerEvents$3() { // 8587
    registerTwoPhaseEvent('onSelect', 
        [
            'focusout', 'contextmenu', 'dragend', 
            'focusin', 'keydown', 'keyup', 
            'mousedown', 'mouseup', 'selectionchange',
        ]
    );
}

function getVendorPrefixedEventName(eventName) {
    return eventName
}

var ANIMATION_END = getVendorPrefixedEventName('animationend'); // 8818
var ANIMATION_ITERATION = getVendorPrefixedEventName('animationiteration');
var ANIMATION_START = getVendorPrefixedEventName('animationstart');
var TRANSITION_END = getVendorPrefixedEventName('transitionend');

var simpleEventPluginEvents = [ // 8833
    'abort', 'auxClick', 'cancel', 'canPlay', 'canPlayThrough', 
    'click', 'close', 'contextMenu', 'copy', 'cut', 
    'drag', 'dragEnd', 'dragEnter', 'dragExit', 'dragLeave', 'dragOver', 'dragStart', 
    'drop', 'durationChange',
    'emptied', 'encrypted', 'ended', 'error', 
    'gotPointerCapture', 'input', 'invalid', 
    'keyDown', 'keyPress', 'keyUp', 
    'load', 'loadedData', 'loadedMetadata', 'loadStart', 'lostPointerCapture', 
    'mouseDown', 'mouseMove', 'mouseOut', 'mouseOver', 'mouseUp', 
    'paste', 'pause', 'play', 'playing', 
    'pointerCancel', 'pointerDown', 'pointerMove', 'pointerOut', 'pointerOver', 'pointerUp', 
    'progress', 'rateChange', 'reset', 'resize', 
    'seeked', 'seeking', 'stalled', 'submit', 'suspend', 
    'timeUpdate', 'touchCancel', 'touchEnd', 'touchStart', 
    'volumeChange', 'scroll', 'toggle', 'touchMove', 'waiting', 'wheel'
]; // 68 events
function registerSimpleEvent(domEventName, reactName) {
    registerTwoPhaseEvent(reactName, [domEventName]);
}
function registerSimpleEvents() {
    for (var i = 0; i < simpleEventPluginEvents.length; i++) {
        var eventName = simpleEventPluginEvents[i];
        var domEventName = eventName.toLowerCase();
        var capitalizedEvent = eventName[0].toUpperCase() + eventName.slice(1);
        registerSimpleEvent(domEventName, 'on' + capitalizedEvent);
    } 
    // Special cases where event names don't match.
    registerSimpleEvent(ANIMATION_END, 'onAnimationEnd');
    registerSimpleEvent(ANIMATION_ITERATION, 'onAnimationIteration');
    registerSimpleEvent(ANIMATION_START, 'onAnimationStart');
    registerSimpleEvent('dblclick', 'onDoubleClick');
    registerSimpleEvent('focusin', 'onFocus');
    registerSimpleEvent('focusout', 'onBlur');
    registerSimpleEvent(TRANSITION_END, 'onTransitionEnd');
}

registerSimpleEvents(); // 9004
registerEvents$2();
registerEvents$1();
registerEvents$3();
registerEvents();
