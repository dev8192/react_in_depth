/*
https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/addEventListener#Safely_detecting_option_support
*/

var passiveBrowserEventsSupported = false;
try {
    var options = {};
    Object.defineProperty(options, 'passive', {
        get: function () {
            // debugger
            console.log(123)
            passiveBrowserEventsSupported = true;
        }
    });
    window.addEventListener('test', options, options);
    window.removeEventListener('test', options, options);
} catch (e) {
    passiveBrowserEventsSupported = false;
}
console.log(passiveBrowserEventsSupported) // true in modern chrome
