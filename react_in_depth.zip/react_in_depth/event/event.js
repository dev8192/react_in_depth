/*
    <script src="event\allNativeEvents.js"></script>
    <script src="event\event.js"></script>

This program shows how 
dispatchEventWithEnableCapturePhaseSelectiveHydrationWithoutDiscreteEventReplay()
works

Rant:
"dispatchEventWithEnableCapturePhaseSelectiveHydrationWithoutDiscreteEventReplay" is 79 characters long.
This is not justified. There are only 3 other functions that begin with "dispatchEvent":
"dispatchEvent",
"dispatchEventForPluginEventSystem", and
"dispatchEventsForPlugins".
The name like "doDispatchEvent" would be more suitable.

Moreover, the separation of functionality between "dispatchEvent" and 
"dispatchEventWithEnableCapturePhaseSelectiveHydrationWithoutDiscreteEventReplay"
is also not justified.
The only work that dispatchEvent does is calling
dispatchEventWithEnableCapturePhaseSelectiveHydrationWithoutDiscreteEventReplay.

dispatchEventWithEnableCapturePhaseSelectiveHydrationWithoutDiscreteEventReplay seems like a joke.
*/

var allNativeEvents = getAllNativeEvents() // 145
var DOCUMENT_NODE = 9 // 2447
var IS_CAPTURE_PHASE = 1 << 2; // 3820
var passiveBrowserEventsSupported = true // 4048

function createEventListenerWrapperWithPriority(targetContainer, domEventName, eventSystemFlags) { // 6413
    return dispatchEvent.bind(null, domEventName, eventSystemFlags, targetContainer);
}

var mediaEventTypes = [ // 9045
    'abort', 'canplay', 'canplaythrough', 'durationchange', 
    'emptied', 'encrypted', 'ended', 'error', 
    'loadeddata', 'loadedmetadata', 'loadstart', 
    'pause', 'play', 'playing', 'progress', 'ratechange', 'resize', 
    'seeked', 'seeking', 'stalled', 'suspend', 
    'timeupdate', 'volumechange', 'waiting'
];
var nonDelegatedEvents = new Set([
    'cancel', 'close', 'invalid', 'load', 'scroll', 'toggle'
].concat(mediaEventTypes));


function dispatchEvent(domEventName, eventSystemFlags, targetContainer, nativeEvent) { // 6464
    dispatchEventWithEnableCapturePhaseSelectiveHydrationWithoutDiscreteEventReplay(
        domEventName, 
        eventSystemFlags, 
        targetContainer, 
        nativeEvent
    );
}

function dispatchEventWithEnableCapturePhaseSelectiveHydrationWithoutDiscreteEventReplay(
    domEventName, 
    eventSystemFlags, 
    targetContainer, 
    nativeEvent
) {
    console.log(
        domEventName, 
        eventSystemFlags, 
        targetContainer, 
        nativeEvent
    )
}

function listenToNativeEvent(domEventName, isCapturePhaseListener, target) { // 9129
    var eventSystemFlags = 0;
    if (isCapturePhaseListener) {
        eventSystemFlags |= IS_CAPTURE_PHASE;
    }
    addTrappedEventListener(target, domEventName, eventSystemFlags, isCapturePhaseListener);
}
var listeningMarker = '_reactListening' + Math.random().toString(36).slice(2); // 9144
function listenToAllSupportedEvents(rootContainerElement) { // 9145
    if (!rootContainerElement[listeningMarker]) {
        rootContainerElement[listeningMarker] = true;
        allNativeEvents.forEach(function (domEventName) {
            if (domEventName !== 'selectionchange') {
                if (!nonDelegatedEvents.has(domEventName)) {
                    listenToNativeEvent(domEventName, false, rootContainerElement);
                }
                listenToNativeEvent(domEventName, true, rootContainerElement);
            }
        });
        var ownerDocument = rootContainerElement.nodeType === DOCUMENT_NODE ? 
            rootContainerElement : 
            rootContainerElement.ownerDocument;
        if (ownerDocument !== null) {
            if (!ownerDocument[listeningMarker]) {
                ownerDocument[listeningMarker] = true;
                listenToNativeEvent('selectionchange', false, ownerDocument);
            }
        }
    }
}

function addTrappedEventListener(
    target,
    eventType,
    eventSystemFlags,
    isCapturePhaseListener,
) { // 9172
    var listener = createEventListenerWrapperWithPriority(target, eventType, eventSystemFlags);
    var isPassiveListener = undefined;
    if (passiveBrowserEventsSupported) {
        if (eventType === 'touchstart' || eventType === 'touchmove' || eventType === 'wheel') {
            isPassiveListener = true;
        }
    }
    if (isCapturePhaseListener) {
        if (isPassiveListener !== undefined) {
            target.addEventListener(eventType, listener, {
                capture: true,
                passive: isPassiveListener
            });
        } else {
            target.addEventListener(eventType, listener, true)
        }
    } else {
        if (isPassiveListener !== undefined) {
            target.addEventListener(eventType, listener, {
                passive: isPassiveListener
            });
        } else {
            target.addEventListener(eventType, listener, false)
        }
    }
}

// entry point
const rootContainerElement = document.createElement('div')
document.body.append(rootContainerElement)
rootContainerElement.style.width = '200px'
rootContainerElement.style.height = '200px'
rootContainerElement.style.backgroundColor = 'gray'
listenToAllSupportedEvents(rootContainerElement)
