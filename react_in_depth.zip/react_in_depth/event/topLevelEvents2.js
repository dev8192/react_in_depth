/*
    <script src="event\allNativeEvents.js"></script>
    <script src="event\topLevelEvents.js"></script>
    <script src="event\topLevelEvents2.js"></script>
*/

const allNativeEvents = getAllNativeEvents()

function test1() {
    const missingEvents = []
    for (const event of topLevelEventsToReactNames.keys()) {
        if (!allNativeEvents.has(event)) {
            missingEvents.push(event)
        }
    }
    console.log(missingEvents)
}

/*
topLevelEventsToReactNames  75
allNativeEvents             81
diff                         6
*/
const diff = [
    "change",
    "selectionchange",
    "compositionend",
    "textInput",
    "compositionstart",
    "compositionupdate"
]
function test() {
    const missingEvents = []
    for (const event of allNativeEvents) {
        if (topLevelEventsToReactNames.get(event) === undefined) {
            missingEvents.push(event)
        }
    }
    console.log(missingEvents)
}

test()
