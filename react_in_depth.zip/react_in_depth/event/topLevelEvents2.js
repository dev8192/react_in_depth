/*
    <script src="event\allNativeEvents.js"></script>
    <script src="event\topLevelEvents.js"></script>
    <script src="event\topLevelEvents2.js"></script>

topLevelEventsToReactNames  75
allNativeEvents             81
How so?
*/

const allNativeEvents = getAllNativeEvents()

function test() {
    const missingEvents = []
    for (const event of topLevelEventsToReactNames.keys()) {
        if (!allNativeEvents.has(event)) {
            missingEvents.push(event)
        }
    }
    console.log(missingEvents)
}

test()
