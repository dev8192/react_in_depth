/*
    <script src="event\allNativeEvents.js"></script>
    <script src="event\eventPriorities.js"></script>

There are 3 event priorities in react-dom.js
(in react.js there are more priorities):

DiscreteEventPriority       dispatchDiscreteEvent       41
ContinuousEventPriority     dispatchContinuousEvent     15
DefaultEventPriority        dispatchEvent               25
TOTAL:                                                  81

*/

const discreteEventPriority = [
    'cancel',
    'click',
    'close',
    'contextmenu',
    'copy',
    'cut',
    'auxclick',
    'dblclick',
    'dragend',
    'dragstart',
    'drop',
    'focusin',
    'focusout',
    'input',
    'invalid',
    'keydown',
    'keypress',
    'keyup',
    'mousedown',
    'mouseup',
    'paste',
    'pause',
    'play',
    'pointercancel',
    'pointerdown',
    'pointerup',
    'ratechange',
    'reset',
    'resize',
    'seeked',
    'submit',
    'touchcancel',
    'touchend',
    'touchstart',
    'volumechange',
    'change',
    'selectionchange',
    'textInput',
    'compositionstart',
    'compositionend',
    'compositionupdate',
]
const discreteEventPriorityNotUsed = [
    "beforeblur",
    "afterblur",
    "beforeinput",
    "blur",
    "fullscreenchange",
    "focus",
    "hashchange",
    "popstate",
    "select",
    "selectstart"
]
const continuousEventPriority = [
    'drag',
    'dragenter',
    'dragexit',
    'dragleave',
    'dragover',
    'mousemove',
    'mouseout',
    'mouseover',
    'pointermove',
    'pointerout',
    'pointerover',
    'scroll',
    'toggle',
    'touchmove',
    'wheel',
]
const continuousEventPriorityNotUsed = [
    "mouseenter",
    "mouseleave",
    "pointerenter",
    "pointerleave",
]
const defaultEventPriority = [
    "abort",
    "canplay",
    "canplaythrough",
    "durationchange",
    "emptied",
    "encrypted",
    "ended",
    "error",
    "gotpointercapture",
    "load",
    "loadeddata",
    "loadedmetadata",
    "loadstart",
    "lostpointercapture",
    "playing",
    "progress",
    "seeking",
    "stalled",
    "suspend",
    "timeupdate",
    "waiting",
    "animationend",
    "animationiteration",
    "animationstart",
    "transitionend"
]

const allNativeEvents = getAllNativeEvents()
console.log(allNativeEvents)

for (const event of discreteEventPriority) {
    allNativeEvents.delete(event)
}
console.log(allNativeEvents)

for (const event of continuousEventPriority) {
    allNativeEvents.delete(event)
}
console.log(allNativeEvents)
