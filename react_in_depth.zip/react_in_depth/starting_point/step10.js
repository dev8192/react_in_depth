ReactDOM.createRoot(document.getElementById('root')).render(
    React.createElement('h1', null, 'Hello World')
)
