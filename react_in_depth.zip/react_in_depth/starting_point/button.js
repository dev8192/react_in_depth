
function App() {
    // debugger
    return React.createElement(
        'button',
        {
            onClick: function() {
                debugger
                console.log('hello')
            },
        },
        'Click Me'
    )
}

const container = document.getElementById('root')
const root = ReactDOM.createRoot(container)
root.render(React.createElement(App))
