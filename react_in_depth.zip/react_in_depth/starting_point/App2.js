
function App() {
    return React.createElement(
        'div',
        { style: { padding: '20px', fontFamily: 'Arial' } },
        React.createElement(
            'h1',
            { style: { color: '#333' } },
            'Hello from React!'
        ),
        React.createElement(
            'p',
            null,
            'No installation • No JSX • No Babel'
        ),
        React.createElement(
            'button',
            {
                onClick: function() { 
                    alert('React works!') 
                },
                style: {
                    padding: '8px 16px',
                    backgroundColor: '#0066ff',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer'
                }
            },
            'Click Me'
        )
    )
}

const container = document.getElementById('root')
debugger
const root = ReactDOM.createRoot(container)
root.render(React.createElement(App))
