/*
    Don't forget to comment div#root in index.html
*/

const container = document.createElement('span')
document.body.append(container)
// container.id = 'root'
const elem = React.createElement('em', null, 'Hello World')
const root = ReactDOM.createRoot(container)
root.render(elem)
