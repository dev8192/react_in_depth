function App() {
    return React.createElement(
        React.Fragment,
        null,
        React.createElement('h1', null, 'Hello'),
        React.createElement('p', null, 'This is a fragment')
    )
}

const container = document.getElementById('root')
const elem = React.createElement(App, null)

// ReactDOM.render(
//     React.createElement(App, null),
//     container
// )

const root = ReactDOM.createRoot(container)
root.render(elem)
