function App() {
    return React.createElement(
        // React.Fragment,
        'div',
        null,
        React.createElement('h1', null, 'Hello'),
        React.createElement('p', null, 'This is a fragment')
    )
}

const container = document.getElementById('root')
const elem = React.createElement(App)
const root = ReactDOM.createRoot(container)
root.render(elem)
