/*
Starting point

TODO: Why do we create 2 FiberNode instances for App?
Why do we use the first FiberNode?
(when we enter the App body, workInProgress is set to the first FiberNode)
What is the purpose of the second FiberNode?
I think this happens only in dev mode:
assignFiberPropertiesInDEV
dummyFiber


*/

/****************************** react.js ******************************/
(function(exports) {
    function createElement(type, config, children) { // 774
        console.log('createElement')
        var props = {}
        props.children = children
        return { type, props }
    }
    function createElementWithValidation() {
        var element = createElement.apply(this, arguments)
        return element
    }
    exports.createElement = createElementWithValidation
})(this.React = {});

/****************************** react-dom.js ******************************/
(function(exports) {
    function enqueueUpdate(fiber, update, lane) { // 14614

    }
    function renderWithHooks(current, workInProgress, Component, props, secondArg, nextRenderLanes) { // 15460
        var children = Component(props, secondArg)
        return children
    }
    function mountIndeterminateComponent(_current, workInProgress, Component, renderLanes) { // 20082
        var value = renderWithHooks(null, workInProgress, Component)
        return value
    }
    function scheduleUpdateOnFiber(root, fiber, lane, eventTime) { // 25527
        if (typeof element.type === 'function') {
            element = mountIndeterminateComponent(null, null, element.type)
        }
        const domElement = document.createElement(element.type)
        domElement.textContent = element.props.children
        root.containerInfo.append(domElement)
    }
    function updateContainer(element, container, parentComponent, callback) { // 28862
        var current$1 = container.current
        var eventTime
        var lane
        var update = {}
        update.payload = {
            element: element
        }
        var root = container
        enqueueUpdate(current$1, update, lane)
        scheduleUpdateOnFiber(root, current$1, lane, eventTime)
    }
    function ReactDOMRoot(internalRoot) { // 29333
        this._internalRoot = internalRoot
    }
    ReactDOMRoot.prototype.render = function(children) { // 29337
        var root = this._internalRoot
        updateContainer(children, root, null, null);
    }
    function createRoot(container) { // 29395
        var root = {containerInfo: container}
        return new ReactDOMRoot(root)
    }
    function createRoot$1(container) { // 29861
        return createRoot(container)
    }
    exports.createRoot = createRoot$1
})(this.ReactDOM = {});

/****************************** app.js ******************************/
(function() {
    function App() {
        return React.createElement(
            'div',
            null,
            'Hello'
        )
    }
    const container = document.createElement('div')
    container.id = 'root'
    document.body.append(container)
    const root = ReactDOM.createRoot(container)
    root.render(React.createElement(App))
})();
