/*
    <script src="react.js"></script>
    <script src="react-dom.js"></script>
    <script src="component/step06.js"></script>
*/

function App() {
    debugger
    return React.createElement(
        'div',
        null,
        'Hello'
    )
}

const container = document.getElementById('root')
const root = ReactDOM.createRoot(container)
root.render(React.createElement(App))
