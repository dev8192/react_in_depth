/*
Template
*/

/****************************** react.js ******************************/
(function(exports) {
    function createElement(type, config, children) { // 774
        var props = {}
        props.children = children
        return { type, props }
    }
    function createElementWithValidation() {
        var element = createElement.apply(this, arguments)
        return element
    }
    exports.createElement = createElementWithValidation
})(this.React = {});

/****************************** react-dom.js ******************************/
(function(exports) {
    function ReactDOMRoot(internalRoot) { // 29333
        this._internalRoot = internalRoot
    }
    ReactDOMRoot.prototype.render = function(children) { // 29337
        var root = this._internalRoot
        const domElement = document.createElement(children.type)
        domElement.textContent = children.props.children
        root.containerInfo.append(domElement)
    }
    function createRoot(container) { // 29395
        var root = {containerInfo: container}
        return new ReactDOMRoot(root)
    }
    function createRoot$1(container) { // 29861
        return createRoot(container)
    }
    exports.createRoot = createRoot$1
})(this.ReactDOM = {});

/****************************** app.js ******************************/
(function() {
    const container = document.createElement('div')
    container.id = 'root'
    document.body.append(container)
    const elem = React.createElement('h1', null, 'Hello World!')
    const root = ReactDOM.createRoot(container)
    root.render(elem)
})();
