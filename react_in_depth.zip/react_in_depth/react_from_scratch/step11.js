/*
The separation of code into 2 separate libraries (react and react-dom)
at this point seems to me completely artificial. What is the point of it?
*/

/****************************** react.js ******************************/
(function(exports) {
    var ReactCurrentOwner = { // 84
        current: null
    };
    var ReactElement = function (type, key, ref, self, source, owner, props) { // 716
        var element = { type, props }
        return element
    }
    function createElement(type, config, children) { // 774
        var props = {}
        var key = null;
        var ref = null;
        var self = null;
        var source = null;
        props.children = children
        return ReactElement(type, key, ref, self, source, ReactCurrentOwner.current, props)
    }
    function createElementWithValidation() {
        var element = createElement.apply(this, arguments)
        return element
    }
    exports.createElement = createElementWithValidation
})(this.React = {});

/****************************** react-dom.js ******************************/
(function(exports) {
    function createElement(type, props, rootContainerElement, parentNamespace) { // 9754
        var ownerDocument = document
        var domElement
        domElement = ownerDocument.createElement(type)
        return domElement
    }
    function createInstance(type, props, rootContainerInstance, hostContext, internalInstanceHandle) { // 10936
        let parentNamespace
        var domElement = createElement(type, props, rootContainerInstance, parentNamespace)
        return domElement
    }

    function FiberRootNode(containerInfo) { // 28652
        this.containerInfo = containerInfo
    }
    function createFiberRoot(containerInfo) { // 28708
        var root = new FiberRootNode(containerInfo)
        return root
    }
    function createContainer(containerInfo) { // 28834
        return createFiberRoot(containerInfo)
    }
    function updateContainer(element, container, parentComponent, callback) { // 28860
        const domElement = createInstance(element.type, {
            textContent: element.children
        })
        domElement.textContent = element.props.children
        container.containerInfo.append(domElement)
    }

    function ReactDOMRoot(internalRoot) { // 29333
        this._internalRoot = internalRoot
    }
    ReactDOMRoot.prototype.render = function(children) { // 29337
        var root = this._internalRoot
        updateContainer(children, root, null, null)
    }

    function createRoot(container) { // 29395
        var root = createContainer(container)
        return new ReactDOMRoot(root)
    }
    function createRoot$1(container, options) { // 29861
        return createRoot(container, options);
    }

    exports.createRoot = createRoot$1
})(this.ReactDOM = {});

/****************************** app.js ******************************/
(function() {
    const container = document.createElement('div')
    document.body.append(container)
    container.id = 'root'
    const elem = React.createElement('h1', null, 'Step11')
    const root = ReactDOM.createRoot(container)
    root.render(elem)
})();
