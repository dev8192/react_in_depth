/*
Starting point

React maintains the illusion of older browser support
by being written in (or being transpiled to) ES5.
If I were to write react from scratch, I would use clean OOP architecture.
Why torture yourself by writing code in ES5 in hope to support older browsers
if your react app will not work (most likely) in those "older browsers" anyway
(for some other technical or security reason, e.g. bot protection)?


*/

class React {
    static createElement(type, config, children) {
        return { type, config, children }
    }
}

class ReactDOM {
    static createRoot(container) {
        return new ReactDOMRoot(container)
    }
}

class ReactDOMRoot {
    constructor(container) {
        this.container = container
    }
    render(children) {
        const domElement = document.createElement(children.type)
        domElement.textContent = children.children
        this.container.append(domElement)
    }
}

const container = document.createElement('div')
document.body.append(container)
container.id = 'root'
const elem = React.createElement('h1', null, 'Step1')
const root = ReactDOM.createRoot(container)
root.render(elem)
