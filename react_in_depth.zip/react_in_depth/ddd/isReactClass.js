/*
What is the point of having 4 functions
(that all basically consist of one simple instruction)
that do the same work?
*/

/****************************** react.js ******************************/
(function(exports) {
    function Component() { // 311
    }
    Component.prototype.isReactComponent = {}; // 321
    function shouldConstruct(Component) { // 1963
        var prototype = Component.prototype;
        return !!(prototype && prototype.isReactComponent);
    }
    console.log(shouldConstruct(Component))
    console.log(shouldConstruct(function() {}))
    exports.Component = Component
})(this.React = {});

/****************************** react-dom.js ******************************/
(function(exports) {
    function shouldConstruct(Component) { // 1179
        var prototype = Component.prototype;
        return !!(prototype && prototype.isReactComponent);
    }

    function isReactClass(type) { // 13048
        return type.prototype && type.prototype.isReactComponent;
    }
    console.log(shouldConstruct(React.Component))
    console.log(shouldConstruct(function() {}))

    function shouldConstruct$1(Component) { // 28190
        var prototype = Component.prototype;
        return !!(prototype && prototype.isReactComponent);
    }
})(this.ReactDOM = {});
