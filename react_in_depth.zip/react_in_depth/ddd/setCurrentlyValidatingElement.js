/*
There are a lot of duplicates in react.js and react-dom.js

****************************** react.js ******************************

createElementWithValidation
    validateChildKeys
    validateFragmentProps
    validatePropTypes

cloneElementWithValidation
    validateChildKeys
    validatePropTypes

validateChildKeys
    validateExplicitKey
        setCurrentlyValidatingElement

validateFragmentProps
    setCurrentlyValidatingElement

validatePropTypes
    checkPropTypes
        setCurrentlyValidatingElement

****************************** react-dom.js ******************************

getMaskedContext
    checkPropTypes
        setCurrentlyValidatingElement

****************************** must be common (but isn't) ******************************

setCurrentlyValidatingElement
    describeUnknownElementTypeFrameInDEV
    setExtraStackFrame

*/

