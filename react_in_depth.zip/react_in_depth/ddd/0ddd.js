/*
This folder contains a collection of code snippets
that illustrate dubious design decisions (ddd) in react
*/