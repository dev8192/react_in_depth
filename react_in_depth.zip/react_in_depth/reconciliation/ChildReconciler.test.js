/*
    <script src="reconciliation\ChildReconciler.js"></script>
    <script src="reconciliation\ChildReconciler.test.js"></script>
*/

function test1() {
    const reconcileChildFibers = ChildReconciler(true)
    const returnFiber = {
        deletions: []
    }
    const currentFirstChild = {
        sibling: null
    }
    reconcileChildFibers(returnFiber, currentFirstChild)
}

/*
reconcileSingleTextNode
*/
function test1() {
    const reconcileChildFibers = ChildReconciler(true)
    const returnFiber = {
        deletions: []
    }
    const currentFirstChild = {
        sibling: null
    }
    const newChild = 'string'
    reconcileChildFibers(returnFiber, currentFirstChild, newChild)
}

/*

*/
function test1() {
    const reconcileChildFibers = ChildReconciler(true)
    const returnFiber = {
        deletions: []
    }
    const currentFirstChild = {
        sibling: null
    }
    const newChild = [0]
    reconcileChildFibers(returnFiber, currentFirstChild, newChild)
}

/*
updateElement
*/
function test() {
    const reconcileChildFibers = ChildReconciler(true)
    const returnFiber = {
        deletions: []
    }
    // const currentFirstChild = {
    //     sibling: null
    // }
    const currentFirstChild = null
    const newChild = [{$$typeof: Symbol.for('react.element')}]
    reconcileChildFibers(returnFiber, currentFirstChild, newChild)
}

test()
