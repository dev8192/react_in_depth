/*
    <script src="reconciliation\ChildReconciler.js"></script>
    <script src="reconciliation\ChildReconciler.test.js"></script>
*/

/*
The simplest test?
*/
function test1() {
    const reconcileChildFibers = ChildReconciler(true)
    const returnFiber = {
        deletions: []
    }
    const currentFirstChild = {
        sibling: null
    }
    reconcileChildFibers(returnFiber, currentFirstChild)
}

/*
reconcileSingleTextNode
*/
function test1() {
    const reconcileChildFibers = ChildReconciler(true)
    const returnFiber = {
        deletions: []
    }
    const currentFirstChild = {
        sibling: null
    }
    const newChild = 'string'
    reconcileChildFibers(returnFiber, currentFirstChild, newChild)
}

/*

*/
function test1() {
    const reconcileChildFibers = ChildReconciler(true)
    const returnFiber = {
        deletions: []
    }
    const currentFirstChild = {
        sibling: null
    }
    const newChild = [0]
    reconcileChildFibers(returnFiber, currentFirstChild, newChild)
}

/*
updateElement
(not working)
*/
function test1() {
    const reconcileChildFibers = ChildReconciler(true)
    const returnFiber = {
        deletions: []
    }
    // const currentFirstChild = {
    //     sibling: null
    // }
    const currentFirstChild = null
    const newChild = [{$$typeof: Symbol.for('react.element')}]
    reconcileChildFibers(returnFiber, currentFirstChild, newChild)
}

/*
reconcileChildFibers
    deleteRemainingChildren
*/
function test1() {
    const reconcileChildFibers = ChildReconciler(true)
    const returnFiber = {
        deletions: []
    }
    const currentFirstChild = {
        sibling: null
    }
    reconcileChildFibers(returnFiber, currentFirstChild)
}

/*
isUnkeyedTopLevelFragment
*/
function test1() {
    const reconcileChildFibers = ChildReconciler(true)
    const returnFiber = {
        deletions: []
    }
    const currentFirstChild = {
        sibling: null
    }
    const newChild = {
        type: REACT_FRAGMENT_TYPE,
        key: null,
        props: {
            children: {

            }
        }
    }
    debugger
    reconcileChildFibers(returnFiber, currentFirstChild, newChild)
}

/*********************************** reconcileSingleElement ***********************************/
/*
reconcileChildFibers
    reconcileSingleElement
        (createFiberFromElement)
    placeSingleChild
*/
function test() {
    const reconcileChildFibers = ChildReconciler(true)
    const returnFiber = {}
    const currentFirstChild = null
    const newChild = {
        $$typeof: REACT_ELEMENT_TYPE
    }
    debugger
    reconcileChildFibers(returnFiber, currentFirstChild, newChild)
}

/*********************************** reconcileSinglePortal ***********************************/

/*********************************** reconcileChildrenArray ***********************************/


/*********************************** reconcileChildrenIterator ***********************************/


/*********************************** reconcileSingleTextNode ***********************************/
/*
reconcileChildFibers
    reconcileSingleTextNode
        deleteRemainingChildren
        createFiberFromText
    placeSingleChild
*/
function test1() {
    const reconcileChildFibers = ChildReconciler(true)
    const returnFiber = {}
    const currentFirstChild = null
    // const newChild = 'hello'
    const newChild = 123
    debugger
    reconcileChildFibers(returnFiber, currentFirstChild, newChild)
}

/*
reconcileChildFibers
    reconcileSingleTextNode
        deleteRemainingChildren
        useFiber
            (createWorkInProgress)
    placeSingleChild
*/
function test1() {
    const reconcileChildFibers = ChildReconciler(true)
    let returnFiber
    const currentFirstChild = {
        tag: HostText,
        sibling: null
    }
    const newChild = 'hello'
    debugger
    reconcileChildFibers(returnFiber, currentFirstChild, newChild)
}

test()
