
// mocks
function getIsHydrating() {}
function getIteratorFn() {}
function throwOnInvalidObjectType() {}
function warnForMissingKey() {}
function createWorkInProgress() {
    return {}
}
function coerceRef() {}
function createFiberFromElement(){
    return {
        alternate: {}
    }
}
var Placement = 2; // 4367

function FiberNode(tag, pendingProps, key, mode) { // 28091
    this.alternate = null
}
var createFiber = function (tag, pendingProps, key, mode) { // 28185
    return new FiberNode(tag, pendingProps, key, mode);
};
function createFiberFromText(content, mode, lanes) { // 28596
    var fiber = createFiber(HostText, content, null, mode);
    fiber.lanes = lanes;
    return fiber;
}

var REACT_PORTAL_TYPE = Symbol.for('react.portal');
var REACT_ELEMENT_TYPE = Symbol.for('react.element');
var REACT_FRAGMENT_TYPE = Symbol.for('react.fragment');
var REACT_LAZY_TYPE = Symbol.for('react.lazy');

var isArrayImpl = Array.isArray;
function isArray(a) {
    return isArrayImpl(a);
}

var HostText = 6;

function ChildReconciler(shouldTrackSideEffects) {
    function deleteChild(returnFiber, childToDelete) {
        if (!shouldTrackSideEffects) {
            return;
        }
        var deletions = returnFiber.deletions;
        if (deletions === null) {
            returnFiber.deletions = [childToDelete];
            returnFiber.flags |= ChildDeletion;
        } else {
            deletions.push(childToDelete);
        }
    }
    function deleteRemainingChildren(returnFiber, currentFirstChild) {
        if (!shouldTrackSideEffects) {
            return null;
        }
        var childToDelete = currentFirstChild;
        while (childToDelete !== null) {
            deleteChild(returnFiber, childToDelete);
            childToDelete = childToDelete.sibling;
        }
        return null;
    }
    function mapRemainingChildren(returnFiber, currentFirstChild) {
        var existingChildren = new Map();
        var existingChild = currentFirstChild;
        while (existingChild !== null) {
            if (existingChild.key !== null) {
                existingChildren.set(existingChild.key, existingChild);
            } else {
                existingChildren.set(existingChild.index, existingChild);
            }

            existingChild = existingChild.sibling;
        }
        return existingChildren;
    }
    function useFiber(fiber, pendingProps) {
        var clone = createWorkInProgress(fiber, pendingProps);
        clone.index = 0;
        clone.sibling = null;
        return clone;
    }
    function placeChild(newFiber, lastPlacedIndex, newIndex) {
        newFiber.index = newIndex;
        if (!shouldTrackSideEffects) {
            newFiber.flags |= Forked;
            return lastPlacedIndex;
        }
        var current = newFiber.alternate;
        if (current !== null) {
            var oldIndex = current.index;
            if (oldIndex < lastPlacedIndex) {
                newFiber.flags |= Placement;
                return lastPlacedIndex;
            } else {
                return oldIndex;
            }
        } else {
            newFiber.flags |= Placement;
            return lastPlacedIndex;
        }
    }
    function placeSingleChild(newFiber) {
        if (shouldTrackSideEffects && newFiber.alternate === null) {
            newFiber.flags |= Placement;
        }
        return newFiber;
    }
    function updateTextNode(returnFiber, current, textContent, lanes) {
        if (current === null || current.tag !== HostText) {
            var created = createFiberFromText(textContent, returnFiber.mode, lanes);
            created.return = returnFiber;
            return created;
        } else {
            var existing = useFiber(current, textContent);
            existing.return = returnFiber;
            return existing;
        }
    }
    function updateElement(returnFiber, current, element, lanes) {
        console.log('updateElement')
        var elementType = element.type;
        if (elementType === REACT_FRAGMENT_TYPE) {
            return updateFragment(returnFiber, current, element.props.children, lanes, element.key);
        }
        if (current !== null) {
            if (
                current.elementType === elementType || (
                    isCompatibleFamilyForHotReloading(current, element)
                ) || typeof elementType === 'object' && 
                elementType !== null && 
                elementType.$$typeof === REACT_LAZY_TYPE && 
                resolveLazy(elementType) === current.type
            ) {
                var existing = useFiber(current, element.props);
                existing.ref = coerceRef(returnFiber, current, element);
                existing.return = returnFiber;
                existing._debugSource = element._source;
                existing._debugOwner = element._owner;
                return existing;
            }
        }
        var created = createFiberFromElement(element, returnFiber.mode, lanes);
        created.ref = coerceRef(returnFiber, current, element);
        created.return = returnFiber;
        return created;
    }
    function updatePortal(returnFiber, current, portal, lanes) {
        if (current === null || current.tag !== HostPortal || current.stateNode.containerInfo !== portal.containerInfo || current.stateNode.implementation !== portal.implementation) {
            var created = createFiberFromPortal(portal, returnFiber.mode, lanes);
            created.return = returnFiber;
            return created;
        } else {
            var existing = useFiber(current, portal.children || []);
            existing.return = returnFiber;
            return existing;
        }
    }
    function updateFragment(returnFiber, current, fragment, lanes, key) {
        if (current === null || current.tag !== Fragment) {
            var created = createFiberFromFragment(fragment, returnFiber.mode, lanes, key);
            created.return = returnFiber;
            return created;
        } else {
            var existing = useFiber(current, fragment);
            existing.return = returnFiber;
            return existing;
        }
    }
    function createChild(returnFiber, newChild, lanes) {
        if (typeof newChild === 'string' && newChild !== '' || typeof newChild === 'number') {
            var created = createFiberFromText('' + newChild, returnFiber.mode, lanes);
            created.return = returnFiber;
            return created;
        }
        if (typeof newChild === 'object' && newChild !== null) {
            switch (newChild.$$typeof) {
                case REACT_ELEMENT_TYPE:
                    {
                        var _created = createFiberFromElement(newChild, returnFiber.mode, lanes);

                        _created.ref = coerceRef(returnFiber, null, newChild);
                        _created.return = returnFiber;
                        return _created;
                    }
                case REACT_PORTAL_TYPE:
                    {
                        var _created2 = createFiberFromPortal(newChild, returnFiber.mode, lanes);

                        _created2.return = returnFiber;
                        return _created2;
                    }
                case REACT_LAZY_TYPE:
                    {
                        var payload = newChild._payload;
                        var init = newChild._init;
                        return createChild(returnFiber, init(payload), lanes);
                    }
            }
            if (isArray(newChild) || getIteratorFn(newChild)) {
                var _created3 = createFiberFromFragment(newChild, returnFiber.mode, lanes, null);
                _created3.return = returnFiber;
                return _created3;
            }
            throwOnInvalidObjectType(returnFiber, newChild);
        }
        if (typeof newChild === 'function') {
            warnOnFunctionType(returnFiber);
        }
        return null;
    }
    function updateSlot(returnFiber, oldFiber, newChild, lanes) {
        var key = oldFiber !== null ? oldFiber.key : null;
        if (typeof newChild === 'string' && newChild !== '' || typeof newChild === 'number') {
            if (key !== null) {
                return null;
            }
            return updateTextNode(returnFiber, oldFiber, '' + newChild, lanes);
        }
        if (typeof newChild === 'object' && newChild !== null) {
            switch (newChild.$$typeof) {
                case REACT_ELEMENT_TYPE:
                    {
                        if (newChild.key === key) {
                            return updateElement(returnFiber, oldFiber, newChild, lanes);
                        } else {
                            return null;
                        }
                    }
                case REACT_PORTAL_TYPE:
                    {
                        if (newChild.key === key) {
                            return updatePortal(returnFiber, oldFiber, newChild, lanes);
                        } else {
                            return null;
                        }
                    }
                case REACT_LAZY_TYPE:
                    {
                        var payload = newChild._payload;
                        var init = newChild._init;
                        return updateSlot(returnFiber, oldFiber, init(payload), lanes);
                    }
            }
            if (isArray(newChild) || getIteratorFn(newChild)) {
                if (key !== null) {
                    return null;
                }
                return updateFragment(returnFiber, oldFiber, newChild, lanes, null);
            }
            throwOnInvalidObjectType(returnFiber, newChild);
        }
        if (typeof newChild === 'function') {
            warnOnFunctionType(returnFiber);
        }
        return null;
    }
    function updateFromMap(existingChildren, returnFiber, newIdx, newChild, lanes) {
        debugger
        if (typeof newChild === 'string' && newChild !== '' || typeof newChild === 'number') {
            var matchedFiber = existingChildren.get(newIdx) || null;
            return updateTextNode(returnFiber, matchedFiber, '' + newChild, lanes);
        }
        if (typeof newChild === 'object' && newChild !== null) {
            switch (newChild.$$typeof) {
                case REACT_ELEMENT_TYPE:
                    {
                        var _matchedFiber = existingChildren.get(newChild.key === null ? newIdx : newChild.key) || null;

                        return updateElement(returnFiber, _matchedFiber, newChild, lanes);
                    }

                case REACT_PORTAL_TYPE:
                    {
                        var _matchedFiber2 = existingChildren.get(newChild.key === null ? newIdx : newChild.key) || null;

                        return updatePortal(returnFiber, _matchedFiber2, newChild, lanes);
                    }

                case REACT_LAZY_TYPE:
                    var payload = newChild._payload;
                    var init = newChild._init;
                    return updateFromMap(existingChildren, returnFiber, newIdx, init(payload), lanes);
            }
            if (isArray(newChild) || getIteratorFn(newChild)) {
                var _matchedFiber3 = existingChildren.get(newIdx) || null;
                return updateFragment(returnFiber, _matchedFiber3, newChild, lanes, null);
            }
            throwOnInvalidObjectType(returnFiber, newChild);
        }
        if (typeof newChild === 'function') {
            warnOnFunctionType(returnFiber);
        }
        return null;
    }
    function warnOnInvalidKey(child, knownKeys, returnFiber) {
        if (typeof child !== 'object' || child === null) {
            return knownKeys;
        }
        switch (child.$$typeof) {
            case REACT_ELEMENT_TYPE:
            case REACT_PORTAL_TYPE:
                warnForMissingKey(child, returnFiber);
                var key = child.key;
                if (typeof key !== 'string') {
                    break;
                }
                if (knownKeys === null) {
                    knownKeys = new Set();
                    knownKeys.add(key);
                    break;
                }
                if (!knownKeys.has(key)) {
                    knownKeys.add(key);
                    break;
                }
                error('Encountered two children with the same key...');
                break;
            case REACT_LAZY_TYPE:
                var payload = child._payload;
                var init = child._init;
                warnOnInvalidKey(init(payload), knownKeys, returnFiber);
                break;
        }
        return knownKeys;
    }
    function reconcileChildrenArray(returnFiber, currentFirstChild, newChildren, lanes) {
        var knownKeys = null;
        for (var i = 0; i < newChildren.length; i++) {
            var child = newChildren[i];
            knownKeys = warnOnInvalidKey(child, knownKeys, returnFiber);
        }
        var resultingFirstChild = null;
        var previousNewFiber = null;
        var oldFiber = currentFirstChild;
        var lastPlacedIndex = 0;
        var newIdx = 0;
        var nextOldFiber = null;
        for (; oldFiber !== null && newIdx < newChildren.length; newIdx++) {
            if (oldFiber.index > newIdx) {
                nextOldFiber = oldFiber;
                oldFiber = null;
            } else {
                nextOldFiber = oldFiber.sibling;
            }
            var newFiber = updateSlot(returnFiber, oldFiber, newChildren[newIdx], lanes);
            if (newFiber === null) {
                if (oldFiber === null) {
                    oldFiber = nextOldFiber;
                }
                break;
            }
            if (shouldTrackSideEffects) {
                if (oldFiber && newFiber.alternate === null) {
                    deleteChild(returnFiber, oldFiber);
                }
            }
            lastPlacedIndex = placeChild(newFiber, lastPlacedIndex, newIdx);
            if (previousNewFiber === null) {
                resultingFirstChild = newFiber;
            } else {
                previousNewFiber.sibling = newFiber;
            }
            previousNewFiber = newFiber;
            oldFiber = nextOldFiber;
        }

        if (newIdx === newChildren.length) {
            deleteRemainingChildren(returnFiber, oldFiber);
            if (getIsHydrating()) {
                var numberOfForks = newIdx;
                pushTreeFork(returnFiber, numberOfForks);
            }
            return resultingFirstChild;
        }

        if (oldFiber === null) {
            for (; newIdx < newChildren.length; newIdx++) {
                var _newFiber = createChild(returnFiber, newChildren[newIdx], lanes);
                if (_newFiber === null) {
                    continue;
                }
                lastPlacedIndex = placeChild(_newFiber, lastPlacedIndex, newIdx);
                if (previousNewFiber === null) {
                    resultingFirstChild = _newFiber;
                } else {
                    previousNewFiber.sibling = _newFiber;
                }
                previousNewFiber = _newFiber;
            }

            if (getIsHydrating()) {
                var _numberOfForks = newIdx;
                pushTreeFork(returnFiber, _numberOfForks);
            }

            return resultingFirstChild;
        }
        var existingChildren = mapRemainingChildren(returnFiber, oldFiber);
        for (; newIdx < newChildren.length; newIdx++) {
            var _newFiber2 = updateFromMap(existingChildren, returnFiber, newIdx, newChildren[newIdx], lanes);
            if (_newFiber2 !== null) {
                if (shouldTrackSideEffects) {
                    if (_newFiber2.alternate !== null) {
                        existingChildren.delete(_newFiber2.key === null ? newIdx : _newFiber2.key);
                    }
                }
                lastPlacedIndex = placeChild(_newFiber2, lastPlacedIndex, newIdx);

                if (previousNewFiber === null) {
                    resultingFirstChild = _newFiber2;
                } else {
                    previousNewFiber.sibling = _newFiber2;
                }

                previousNewFiber = _newFiber2;
            }
        }
        if (shouldTrackSideEffects) {
            existingChildren.forEach(function (child) {
                return deleteChild(returnFiber, child);
            });
        }
        if (getIsHydrating()) {
            var _numberOfForks2 = newIdx;
            pushTreeFork(returnFiber, _numberOfForks2);
        }
        return resultingFirstChild;
    }
    function reconcileChildrenIterator(returnFiber, currentFirstChild, newChildrenIterable, lanes) {
        var iteratorFn = getIteratorFn(newChildrenIterable);
        if (typeof iteratorFn !== 'function') {
            throw new Error('An object is not an iterable. This error is likely caused by a bug in ' + 'React. Please file an issue.');
        }
        if (
            typeof Symbol === 'function' &&
            newChildrenIterable[Symbol.toStringTag] === 'Generator'
        ) {
            if (!didWarnAboutGenerators) {
                error('Using Generators as children is unsupported...');
            }

            didWarnAboutGenerators = true;
        }
        if (newChildrenIterable.entries === iteratorFn) {
            if (!didWarnAboutMaps) {
                error('Using Maps as children is not supported. ' + 'Use an array of keyed ReactElements instead.');
            }

            didWarnAboutMaps = true;
        }
        var _newChildren = iteratorFn.call(newChildrenIterable);
        if (_newChildren) {
            var knownKeys = null;

            var _step = _newChildren.next();

            for (; !_step.done; _step = _newChildren.next()) {
                var child = _step.value;
                knownKeys = warnOnInvalidKey(child, knownKeys, returnFiber);
            }
        }
        var newChildren = iteratorFn.call(newChildrenIterable);
        if (newChildren == null) {
            throw new Error('An iterable object provided no iterator.');
        }
        var resultingFirstChild = null;
        var previousNewFiber = null;
        var oldFiber = currentFirstChild;
        var lastPlacedIndex = 0;
        var newIdx = 0;
        var nextOldFiber = null;
        var step = newChildren.next();

        for (; oldFiber !== null && !step.done; newIdx++, step = newChildren.next()) {
            if (oldFiber.index > newIdx) {
                nextOldFiber = oldFiber;
                oldFiber = null;
            } else {
                nextOldFiber = oldFiber.sibling;
            }

            var newFiber = updateSlot(returnFiber, oldFiber, step.value, lanes);

            if (newFiber === null) {
                if (oldFiber === null) {
                    oldFiber = nextOldFiber;
                }
                break;
            }

            if (shouldTrackSideEffects) {
                if (oldFiber && newFiber.alternate === null) {
                    deleteChild(returnFiber, oldFiber);
                }
            }
            lastPlacedIndex = placeChild(newFiber, lastPlacedIndex, newIdx);

            if (previousNewFiber === null) {
                resultingFirstChild = newFiber;
            } else {
                previousNewFiber.sibling = newFiber;
            }

            previousNewFiber = newFiber;
            oldFiber = nextOldFiber;
        }

        if (step.done) {
            deleteRemainingChildren(returnFiber, oldFiber);

            if (getIsHydrating()) {
                var numberOfForks = newIdx;
                pushTreeFork(returnFiber, numberOfForks);
            }

            return resultingFirstChild;
        }
        if (oldFiber === null) {
            for (; !step.done; newIdx++, step = newChildren.next()) {
                var _newFiber3 = createChild(returnFiber, step.value, lanes);

                if (_newFiber3 === null) {
                    continue;
                }

                lastPlacedIndex = placeChild(_newFiber3, lastPlacedIndex, newIdx);

                if (previousNewFiber === null) {
                    resultingFirstChild = _newFiber3;
                } else {
                    previousNewFiber.sibling = _newFiber3;
                }

                previousNewFiber = _newFiber3;
            }

            if (getIsHydrating()) {
                var _numberOfForks3 = newIdx;
                pushTreeFork(returnFiber, _numberOfForks3);
            }

            return resultingFirstChild;
        }
        var existingChildren = mapRemainingChildren(returnFiber, oldFiber);
        for (; !step.done; newIdx++, step = newChildren.next()) {
            var _newFiber4 = updateFromMap(existingChildren, returnFiber, newIdx, step.value, lanes);

            if (_newFiber4 !== null) {
                if (shouldTrackSideEffects) {
                    if (_newFiber4.alternate !== null) {
                        existingChildren.delete(_newFiber4.key === null ? newIdx : _newFiber4.key);
                    }
                }
                lastPlacedIndex = placeChild(_newFiber4, lastPlacedIndex, newIdx);
                if (previousNewFiber === null) {
                    resultingFirstChild = _newFiber4;
                } else {
                    previousNewFiber.sibling = _newFiber4;
                }

                previousNewFiber = _newFiber4;
            }
        }
        if (shouldTrackSideEffects) {
            existingChildren.forEach(function (child) {
                return deleteChild(returnFiber, child);
            });
        }
        if (getIsHydrating()) {
            var _numberOfForks4 = newIdx;
            pushTreeFork(returnFiber, _numberOfForks4);
        }
        return resultingFirstChild;
    }
    function reconcileSingleTextNode(returnFiber, currentFirstChild, textContent, lanes) {
        if (currentFirstChild !== null && currentFirstChild.tag === HostText) {
            deleteRemainingChildren(returnFiber, currentFirstChild.sibling);
            var existing = useFiber(currentFirstChild, textContent);
            existing.return = returnFiber;
            return existing;
        }
        deleteRemainingChildren(returnFiber, currentFirstChild);
        var created = createFiberFromText(textContent, returnFiber.mode, lanes);
        created.return = returnFiber;
        return created;
    }
    function reconcileSingleElement(returnFiber, currentFirstChild, element, lanes) {
        var key = element.key;
        var child = currentFirstChild;
        while (child !== null) {
            if (child.key === key) {
                var elementType = element.type;
                if (elementType === REACT_FRAGMENT_TYPE) {
                    if (child.tag === Fragment) {
                        deleteRemainingChildren(returnFiber, child.sibling);
                        var existing = useFiber(child, element.props.children);
                        existing.return = returnFiber;
                        existing._debugSource = element._source;
                        existing._debugOwner = element._owner;
                        return existing;
                    }
                } else {
                    if (
                        child.elementType === elementType ||
                        isCompatibleFamilyForHotReloading(child, element) || 
                        typeof elementType === 'object' && 
                        elementType !== null && 
                        elementType.$$typeof === REACT_LAZY_TYPE && 
                        resolveLazy(elementType) === child.type
                    ) {
                        deleteRemainingChildren(returnFiber, child.sibling);
                        var _existing = useFiber(child, element.props);
                        _existing.ref = coerceRef(returnFiber, child, element);
                        _existing.return = returnFiber;
                        _existing._debugSource = element._source;
                        _existing._debugOwner = element._owner;
                        return _existing;
                    }
                }
                deleteRemainingChildren(returnFiber, child);
                break;
            } else {
                deleteChild(returnFiber, child);
            }
            child = child.sibling;
        }

        if (element.type === REACT_FRAGMENT_TYPE) {
            var created = createFiberFromFragment(element.props.children, returnFiber.mode, lanes, element.key);
            created.return = returnFiber;
            return created;
        } else {
            var _created4 = createFiberFromElement(element, returnFiber.mode, lanes);
            _created4.ref = coerceRef(returnFiber, currentFirstChild, element);
            _created4.return = returnFiber;
            return _created4;
        }
    }

    function reconcileSinglePortal(returnFiber, currentFirstChild, portal, lanes) {
        var key = portal.key;
        var child = currentFirstChild;
        while (child !== null) {
            if (child.key === key) {
                if (child.tag === HostPortal && child.stateNode.containerInfo === portal.containerInfo && child.stateNode.implementation === portal.implementation) {
                    deleteRemainingChildren(returnFiber, child.sibling);
                    var existing = useFiber(child, portal.children || []);
                    existing.return = returnFiber;
                    return existing;
                } else {
                    deleteRemainingChildren(returnFiber, child);
                    break;
                }
            } else {
                deleteChild(returnFiber, child);
            }
            child = child.sibling;
        }

        var created = createFiberFromPortal(portal, returnFiber.mode, lanes);
        created.return = returnFiber;
        return created;
    }
    function reconcileChildFibers(returnFiber, currentFirstChild, newChild, lanes) {
        var isUnkeyedTopLevelFragment = typeof newChild === 'object' && newChild !== null && newChild.type === REACT_FRAGMENT_TYPE && newChild.key === null;
        if (isUnkeyedTopLevelFragment) {
            newChild = newChild.props.children;
        }
        if (typeof newChild === 'object' && newChild !== null) {
            switch (newChild.$$typeof) {
                case REACT_ELEMENT_TYPE:
                    return placeSingleChild(reconcileSingleElement(returnFiber, currentFirstChild, newChild, lanes));
                case REACT_PORTAL_TYPE:
                    return placeSingleChild(reconcileSinglePortal(returnFiber, currentFirstChild, newChild, lanes));
                case REACT_LAZY_TYPE:
                    var payload = newChild._payload;
                    var init = newChild._init; // TODO: This function is supposed to be non-recursive.
                    return reconcileChildFibers(returnFiber, currentFirstChild, init(payload), lanes);
            }
            if (isArray(newChild)) {
                return reconcileChildrenArray(returnFiber, currentFirstChild, newChild, lanes);
            }
            if (getIteratorFn(newChild)) {
                return reconcileChildrenIterator(returnFiber, currentFirstChild, newChild, lanes);
            }
            throwOnInvalidObjectType(returnFiber, newChild);
        }
        if (typeof newChild === 'string' && newChild !== '' || typeof newChild === 'number') {
            return placeSingleChild(reconcileSingleTextNode(returnFiber, currentFirstChild, '' + newChild, lanes));
        }
        if (typeof newChild === 'function') {
            warnOnFunctionType(returnFiber);
        }
        return deleteRemainingChildren(returnFiber, currentFirstChild);
    }
    return reconcileChildFibers;
}
