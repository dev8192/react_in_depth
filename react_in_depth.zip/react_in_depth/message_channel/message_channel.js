/*
    TODO: 4ms setTimeout clamping
*/

var performWorkUntilDeadline = function () { // 2905
    debugger
    console.log('performWorkUntilDeadline')
}

function test1() {
    performWorkUntilDeadline()
}

function test() {
    var localSetTimeout = typeof setTimeout === 'function' ? setTimeout : null
    var schedulePerformWorkUntilDeadline = function () {
        localSetTimeout(performWorkUntilDeadline, 0);
    };
    schedulePerformWorkUntilDeadline()
}

function test1() {
    var channel = new MessageChannel(); // 2957
    var port = channel.port2;
    channel.port1.onmessage = performWorkUntilDeadline;
    var schedulePerformWorkUntilDeadline = function () { // 2961
        port.postMessage(null);
    };
    schedulePerformWorkUntilDeadline();
}

test()
