/*

https://github.com/facebook/react/releases/tag/v18.3.1

https://unpkg.com/react@18/umd/react.development.js
https://unpkg.com/react-dom@18/umd/react-dom.development.js


TODO: Babel for JSX processing
https://unpkg.com/@babel/standalone/babel.js


give me a simple react program without jsx that shows how to use react fragment


*/