/*
This program shows how useTransition() works
*/

/****************************** react.js ******************************/
(function(exports) {
    var ReactCurrentDispatcher = { // 55
        current: null
    }
    function resolveDispatcher() { // 1586
        var dispatcher = ReactCurrentDispatcher.current;
        return dispatcher;
    }
    function useTransition() { // 1661
        var dispatcher = resolveDispatcher();
        return dispatcher.useTransition();
    }
    var ReactSharedInternals$1 = {
        ReactCurrentDispatcher: ReactCurrentDispatcher,
    }
    exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = ReactSharedInternals$1;
    exports.useTransition = useTransition
})(this.React = {});

/****************************** react-dom.js ******************************/
(function(exports) {
    var ReactSharedInternals = React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED; // 17
    var ReactCurrentDispatcher$1 = ReactSharedInternals.ReactCurrentDispatcher // 15305
    var currentlyRenderingFiber$1 = null; // 15318
    function renderWithHooks(current, workInProgress) { // 15460
        currentlyRenderingFiber$1 = workInProgress;
        ReactCurrentDispatcher$1.current = HooksDispatcherOnMountInDEV;
    }
    function mountState(initialState) { // 16176
        var dispatch = dispatchSetState.bind(null, currentlyRenderingFiber$1);
        return [123, dispatch]
    }
    function startTransition(setPending, callback, options) { // 16513
        callback()
    }
    function mountTransition() { // 16546
        var _mountState = mountState(false),
            isPending = _mountState[0],
            setPending = _mountState[1];
        var start = startTransition.bind(null, setPending);
        return [isPending, start];
    }
    function dispatchSetState(fiber, queue, action) { // 16655

    }
    var HooksDispatcherOnMountInDEV = null; // 16801
    HooksDispatcherOnMountInDEV = {
        useTransition: function () { // 16909
            return mountTransition();
        },
    }
    renderWithHooks() // hack
})(this.ReactDOM = {});

/****************************** app.js ******************************/
(function() {
    const [isPending, startTransition] = React.useTransition()
    console.log(isPending)
    startTransition(() => {
        console.log('startTransition')
    })
})();
