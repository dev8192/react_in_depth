/*
Starting point
*/

/****************************** react.js ******************************/
(function(exports) {
    function useTransition() { // 1661
        return [true, function(callback) {
            callback()
        }]
    }
    exports.useTransition = useTransition
})(this.React = {});

/****************************** react-dom.js ******************************/
(function(exports) {
    // empty
})(this.ReactDOM = {});

/****************************** app.js ******************************/
(function() {
    const [isPending, startTransition] = React.useTransition()
    console.log(isPending)
    startTransition(() => {
        console.log('startTransition!')
    })
})();
