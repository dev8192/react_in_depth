
const _container = document.createElement('div')
_container.id = 'root'
document.body.append(_container)


class React{
    static rootElem
    static createElement(type, props, ...arr) {

        let elem
        if (typeof type === 'function'){
            this.rootElem = type
            return type
        } else {
            elem = document.createElement(type)
        }
        if (typeof props === 'object' && props !== null){
            elem.addEventListener('click', () => {
                props.onClick()
                ReactDOM.root.render(this.rootElem)
            })
        }
        for(const item of arr){
            if (typeof arr === 'string'){
                elem.textContent = item
            } else {
                elem.append(item)
            }
        }
        return elem
    }

    static value
    static useState(param){
        if (React.value === undefined){
            React.value = param
        }
        function setValue (newValue){
            React.value = newValue
        }
        return [ this.value, setValue ]
    }
}

class ReactDOM {
    static createRoot(container){
        const root = {
            render(obj){
                if (typeof obj === 'function'){
                    container.textContent = ''
                    obj = obj()
                }
                container.append(obj)
            }
        }
        ReactDOM.root = root
        return root
    }
}
