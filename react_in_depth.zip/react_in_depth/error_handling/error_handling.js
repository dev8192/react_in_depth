/*
This program shows how errors and warnings are printed in React
*/

var suppressWarning = false;
function setSuppressWarning(newSuppressWarning) {
    suppressWarning = newSuppressWarning;
}
function warn(format) {
    if (!suppressWarning) {
        for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
            args[_key - 1] = arguments[_key];
        }

        printWarning('warn', format, args);
    }
}
function error(format) {
    if (!suppressWarning) {
        for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
            args[_key2 - 1] = arguments[_key2];
        }
        printWarning('error', format, args);
    }
}

function printWarning(level, format, args) {
    var ReactDebugCurrentFrame = ReactSharedInternals.ReactDebugCurrentFrame;
    var stack = ReactDebugCurrentFrame.getStackAddendum();
    if (stack !== '') {
        format += '%s';
        args = args.concat([stack]);
    }
    var argsWithFormat = args.map(function (item) {
        return String(item);
    });
    argsWithFormat.unshift('Warning: ' + format);
    Function.prototype.apply.call(console[level], console, argsWithFormat);
}

