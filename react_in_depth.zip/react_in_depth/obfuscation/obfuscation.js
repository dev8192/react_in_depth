/*
minification vs obfuscation
*/
function ec(a) {
    a = a[Da] || a[Ja];
    return !a || (5 !== a.tag && 6 !== a.tag && 13 !== a.tag && 3 !== a.tag)
    ? null
    : a;
}

function getInstanceFromNode(node) {
    var inst = node[internalInstanceKey] || node[internalContainerInstanceKey];
    if (inst) {
        if (
            inst.tag === HostComponent || inst.tag === HostText || 
            inst.tag === SuspenseComponent || inst.tag === HostRoot
        ) {
            return inst;
        } else {
            return null;
        }
    }
    return null;
}
