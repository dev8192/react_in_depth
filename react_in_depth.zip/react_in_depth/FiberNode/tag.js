/*
This program shows how FiberNode instances
are created for hello.js (conceptually)
*/

/****************************** react.js ******************************/
(function(exports) {
    var num = 333
    exports.example = 'React'
})(this.React = {});

/****************************** react-dom.js ******************************/
(function(exports) {
    var IndeterminateComponent = 2
    var HostRoot = 3
    var HostComponent = 5

    function FiberNode(tag) {
        console.log(tag)
    }
    var createFiber = function (tag) {
        return new FiberNode(tag)
    }

    createFiber(HostRoot)
    setTimeout(() => {
        createFiber(HostRoot)
        createFiber(IndeterminateComponent)
        createFiber(HostComponent)
        createFiber(IndeterminateComponent)
    })
})(this.ReactDOM = {});

/****************************** app.js ******************************/
(function() {

})();
