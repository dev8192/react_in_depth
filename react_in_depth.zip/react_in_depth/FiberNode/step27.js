/*
This program shows how FiberNode instances are created and used in React.
In particular, it shows how the very first FiberNode instance is created.
It is based on template2.js.

There are 5 FiberNode's and 2 workInProgress's
even for the simplest react program:
starting_point\hello.js
*/

/****************************** react.js ******************************/
(function(exports) {
    function createElement(type, config, children) { // 774
        var props = {}
        props.children = children
        return { type, props }
    }
    function createElementWithValidation() {
        var element = createElement.apply(this, arguments)
        return element
    }
    exports.createElement = createElementWithValidation
})(this.React = {});

/****************************** react-dom.js ******************************/
(function(exports) {
    var HostRoot = 3; // 82
    function FiberNode(tag, pendingProps, key, mode) { // 28088
        console.log(FiberNode)
    }
    var createFiber = function (tag, pendingProps, key, mode) { // 28167
        return new FiberNode(tag, pendingProps, key, mode);
    };
    function createHostRootFiber(tag, isStrictMode, concurrentUpdatesByDefaultOverride) { // 28352
        var mode;
        return createFiber(HostRoot, null, null, mode)
    }
    function createFiberRoot(
        containerInfo,
        tag,
        hydrate,
        initialChildren,
        hydrationCallbacks,
        isStrictMode,
        concurrentUpdatesByDefaultOverride,
        identifierPrefix,
        onRecoverableError,
        transitionCallbacks
    ) { // 28710
        var root = {containerInfo}
        var uninitializedFiber = createHostRootFiber(tag, isStrictMode)
        root.current = uninitializedFiber
        return root
    }
    function createContainer(
        containerInfo,
        tag,
        hydrationCallbacks,
        isStrictMode,
        concurrentUpdatesByDefaultOverride,
        identifierPrefix,
        onRecoverableError,
        transitionCallbacks
    ) { // 28836
        var hydrate = false;
        var initialChildren = null;
        return createFiberRoot(
            containerInfo,
            tag,
            hydrate,
            initialChildren,
            hydrationCallbacks,
            isStrictMode,
            concurrentUpdatesByDefaultOverride,
            identifierPrefix,
            onRecoverableError
        );
    }
    function ReactDOMRoot(internalRoot) { // 29333
        this._internalRoot = internalRoot
    }
    ReactDOMRoot.prototype.render = function(children) { // 29337
        var root = this._internalRoot
        const domElement = document.createElement(children.type)
        domElement.textContent = children.props.children
        root.containerInfo.append(domElement)
    }
    function createRoot(container) { // 29395
        var root = createContainer(
            container,
        );
        return new ReactDOMRoot(root)
    }
    function createRoot$1(container) { // 29861
        return createRoot(container)
    }
    exports.createRoot = createRoot$1
})(this.ReactDOM = {});

/****************************** app.js ******************************/
(function() {
    const container = document.createElement('div')
    container.id = 'root'
    document.body.append(container)
    const elem = React.createElement('h1', null, 'Hello World!')
    const root = ReactDOM.createRoot(container)
    root.render(elem)
})();
