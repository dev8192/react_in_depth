/*
Add taskQueue


*/

/****************************** react.js ******************************/
(function(exports) {
    function push(heap, node) { // 2426
        heap.push(node);
    }
    function peek(heap) { // 2431
        return heap[0]
    }
    var taskQueue = []; // 2549
    var currentTask = null; // 2553
    function workLoop(hasTimeRemaining, initialTime) { // 2644
        currentTask = peek(taskQueue);
        var callback = currentTask.callback
        return callback()
    }
    function flushWork(hasTimeRemaining, initialTime) { // 2606
        return workLoop()
    }
    function unstable_scheduleCallback(priorityLevel, callback, options) { // 2761
        var newTask = {
            callback: callback,
        };
        push(taskQueue, newTask)
        requestHostCallback(flushWork)
    }

    var isMessageLoopRunning = false; // 2871
    var scheduledHostCallback = null; // 2872
    var performWorkUntilDeadline = function () { // 2913
        if (scheduledHostCallback !== null) {
            var hasMoreWork = scheduledHostCallback()
            if (hasMoreWork) {
                schedulePerformWorkUntilDeadline();
            } else {
                isMessageLoopRunning = false;
                scheduledHostCallback = null;
            }
        } else {
            isMessageLoopRunning = false;
        }
    }

    var channel = new MessageChannel(); // 2957
    channel.port1.onmessage = performWorkUntilDeadline;
    var schedulePerformWorkUntilDeadline = function () { // 2961
        channel.port2.postMessage(null);
    };
    function requestHostCallback(callback) { // 2979
        scheduledHostCallback = callback;
        if (!isMessageLoopRunning) {
            isMessageLoopRunning = true;
            schedulePerformWorkUntilDeadline();
        }
    }
    var Scheduler = { // 3004
        unstable_scheduleCallback: unstable_scheduleCallback,
    }
    var ReactSharedInternals$1 = { // 3027
        Scheduler: Scheduler
    };
    exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = ReactSharedInternals$1
})(this.React = {});

/****************************** react-dom.js ******************************/
(function(exports) {
    var ReactInternals = React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
    var _ReactInternals$Sched = ReactInternals.Scheduler,
        unstable_scheduleCallback = _ReactInternals$Sched.unstable_scheduleCallback

    var scheduleCallback = unstable_scheduleCallback; // 4768
    function renderWithHooks(current, workInProgress, Component, props, secondArg, nextRenderLanes) { // 15460
        Component()
    }
    function mountIndeterminateComponent(_current, workInProgress, Component, renderLanes) { // 20082
        renderWithHooks(null, workInProgress, Component)
    }
    function beginWork(current, workInProgress, renderLanes) { // 21569
        mountIndeterminateComponent(current, workInProgress, workInProgress.type)
    }
    var workInProgress = null; // 25349
    workInProgress = { // hack
        type: function() {
            console.log(888)
        }
    }
    function scheduleUpdateOnFiber(root, fiber, lane, eventTime) { // 25527
        ensureRootIsScheduled()
    }
    function ensureRootIsScheduled(root, currentTime) { // 25626
        var schedulerPriorityLevel
        scheduleCallback$1(schedulerPriorityLevel, performConcurrentWorkOnRoot.bind(null, root));
    }
    function performConcurrentWorkOnRoot(root, didTimeout) { // 25745
        var exitStatus = renderRootSync()
    }
    function renderRootSync(root, lanes) { // 26454
        workLoopSync();
    }
    function workLoopSync() { // 26517
        performUnitOfWork(workInProgress)
    }
    function performUnitOfWork(unitOfWork) { // 26601
        var current
        beginWork$1(current, unitOfWork)
    }
    var beginWork$1 = function (current, unitOfWork, lanes) { // 27471
        beginWork(current, unitOfWork)
    }
    function scheduleCallback$1(priorityLevel, callback) { // 27581
        return scheduleCallback(priorityLevel, callback)
    }
    function updateContainer(element, container, parentComponent, callback) { // 28862
        scheduleUpdateOnFiber()
    }
    function ReactDOMRoot(internalRoot) { // 29333
        this._internalRoot = internalRoot
    }
    ReactDOMRoot.prototype.render = function(children) { // 29337
        var root = this._internalRoot
        updateContainer(children, root, null, null);
    }
    function createRoot(container) { // 29395
        var root = {containerInfo: container}
        return new ReactDOMRoot(root)
    }
    function createRoot$1(container) { // 29861
        return createRoot(container)
    }
    exports.createRoot = createRoot$1
})(this.ReactDOM = {});

/****************************** app.js ******************************/
(function() {
    const root = ReactDOM.createRoot()
    root.render()
})();
