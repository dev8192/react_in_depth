/*
Add unstable_scheduleCallback()
Add flushWork()
*/


/****************************** react.js ******************************/
(function(exports) {
    let counter = 3
    function flushWork(hasTimeRemaining, initialTime) { // 2606
        console.log(444)
        counter--
        return counter > 0
    }
    function unstable_scheduleCallback(priorityLevel, callback, options) { // 2761
        requestHostCallback(flushWork);
    }

    var isMessageLoopRunning = false; // 2871
    var scheduledHostCallback = null; // 2872
    var performWorkUntilDeadline = function () { // 2913
        if (scheduledHostCallback !== null) {
            var hasMoreWork = scheduledHostCallback()
            if (hasMoreWork) {
                schedulePerformWorkUntilDeadline();
            } else {
                isMessageLoopRunning = false;
                scheduledHostCallback = null;
            }
        } else {
            isMessageLoopRunning = false;
        }
    }

    var channel = new MessageChannel(); // 2957
    channel.port1.onmessage = performWorkUntilDeadline;
    var schedulePerformWorkUntilDeadline = function () { // 2961
        channel.port2.postMessage(null);
    };
    function requestHostCallback(callback) { // 2979
        scheduledHostCallback = callback;
        if (!isMessageLoopRunning) {
            isMessageLoopRunning = true;
            schedulePerformWorkUntilDeadline();
        }
    }
})(this.React = {});

/****************************** react-dom.js ******************************/
(function(exports) {
    var ReactInternals = React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
    var _ReactInternals$Sched = ReactInternals.Scheduler,
        unstable_scheduleCallback = _ReactInternals$Sched.unstable_scheduleCallback

    var scheduleCallback = unstable_scheduleCallback; // 4768
    function scheduleCallback$1(priorityLevel, callback) { // 27581
        scheduleCallback()
    }
    setTimeout(() => {
        scheduleCallback$1()
    })
})(this.ReactDOM = {});

/****************************** app.js ******************************/
(function() {
    // empty
})();
