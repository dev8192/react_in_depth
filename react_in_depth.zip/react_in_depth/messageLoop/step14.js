/*
Add scheduledHostCallback
*/


/****************************** react.js ******************************/
(function(exports) {
    var isMessageLoopRunning = false;
    var scheduledHostCallback = null; // 2872
    var performWorkUntilDeadline = function () { // 2913
        if (scheduledHostCallback !== null) {
            hasMoreWork = scheduledHostCallback();
        } else {
            isMessageLoopRunning = false;
        }
    }

    var channel = new MessageChannel(); // 2957
    channel.port1.onmessage = performWorkUntilDeadline;
    var schedulePerformWorkUntilDeadline = function () { // 2961
        channel.port2.postMessage(null);
    };
    function requestHostCallback(callback) { // 2979
        scheduledHostCallback = callback;
        if (!isMessageLoopRunning) {
            isMessageLoopRunning = true;
            schedulePerformWorkUntilDeadline();
        }
    }
    requestHostCallback(() => {
        console.log(333)
    }); // hack
})(this.React = {});

/****************************** react-dom.js ******************************/
(function(exports) {
    // empty
})(this.ReactDOM = {});

/****************************** app.js ******************************/
(function() {
    // empty
})();
