/*
Starting point

Message loop is the core mechanism in React.
It is built on top of MessageChannel.

TODO: Read about 4ms setTimeout clamping
Is it such a big deal?
*/

var performWorkUntilDeadline = function () { // 2905
    debugger
    console.log('performWorkUntilDeadline')
}

/*
Option 1: We can call a function directly
*/
function test1() {
    performWorkUntilDeadline()
}

/*
Option 2: We can a function via setTimeout()
Rant: What is the point of doing "typeof setTimeout === 'function'"?
*/
function test() {
    var localSetTimeout = typeof setTimeout === 'function' ? setTimeout : null
    var schedulePerformWorkUntilDeadline = function () {
        localSetTimeout(performWorkUntilDeadline, 0);
    };
    schedulePerformWorkUntilDeadline()
}

/*
Option 3: We can a function via MessageChannel
*/
function test1() {
    var channel = new MessageChannel(); // 2957
    channel.port1.onmessage = performWorkUntilDeadline;
    var schedulePerformWorkUntilDeadline = function () { // 2961
        channel.port2.postMessage(null);
    };
    schedulePerformWorkUntilDeadline();
}

test()
