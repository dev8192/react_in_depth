/*
    <script src="react.js"></script>
    <script src="react-dom.js"></script>
    <script src="button/step05.js"></script>
*/

const container = document.createElement('div')
document.body.append(container)
const root = ReactDOM.createRoot(container)
root.render(React.createElement(
    'button',
    {
        onClick: function() {
            // debugger
            console.log('hello')
        },
    },
    'Click Me'
))
