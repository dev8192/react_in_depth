/*
Add dispatchEvent()
*/

/****************************** react.js ******************************/
(function(exports) {
    function createElement(type, config, children) { // 774
        var props = {}
        props.children = children
        return { type, props }
    }
    function createElementWithValidation() {
        var element = createElement.apply(this, arguments)
        return element
    }
    exports.createElement = createElementWithValidation
})(this.React = {});

/****************************** react-dom.js ******************************/
(function(exports) {
    var allNativeEvents = new Set([ // 145
        'click'
    ])
    var IS_CAPTURE_PHASE = 1 << 2 // 3820

    function createEventListenerWrapperWithPriority(targetContainer, domEventName, eventSystemFlags) { // 6413
        return dispatchEvent.bind(null, domEventName, eventSystemFlags, targetContainer)
    }

    function dispatchEvent(domEventName, eventSystemFlags, targetContainer, nativeEvent) { // 6464
        dispatchEventWithEnableCapturePhaseSelectiveHydrationWithoutDiscreteEventReplay(
            domEventName, 
            eventSystemFlags, 
            targetContainer, 
            nativeEvent
        )
    }

    function dispatchEventWithEnableCapturePhaseSelectiveHydrationWithoutDiscreteEventReplay(
        domEventName, 
        eventSystemFlags, 
        targetContainer, 
        nativeEvent
    ) {
        console.log(
            domEventName, 
            eventSystemFlags, 
            targetContainer, 
            nativeEvent
        )
    }

    function listenToNativeEvent(domEventName, isCapturePhaseListener, target) { // 9129
        var eventSystemFlags = 0
        if (isCapturePhaseListener) {
            eventSystemFlags |= IS_CAPTURE_PHASE
        }
        addTrappedEventListener(target, domEventName, eventSystemFlags, isCapturePhaseListener)
    }
    function listenToAllSupportedEvents(rootContainerElement) { // 9145
        allNativeEvents.forEach(function (domEventName) {
            listenToNativeEvent(domEventName, false, rootContainerElement)
            listenToNativeEvent(domEventName, true, rootContainerElement)
        })
    }

    function addTrappedEventListener(
        target,
        eventType,
        eventSystemFlags,
        isCapturePhaseListener,
    ) { // 9172
        var listener = createEventListenerWrapperWithPriority(target, eventType, eventSystemFlags)
        if (isCapturePhaseListener) {
            target.addEventListener(eventType, listener, true)
        } else {
            target.addEventListener(eventType, listener, false)
        }
    }

    function ReactDOMRoot(internalRoot) { // 29333
        this._internalRoot = internalRoot
    }
    ReactDOMRoot.prototype.render = function(children) { // 29337
        var root = this._internalRoot
        const domElement = document.createElement(children.type)
        domElement.textContent = children.props.children
        root.containerInfo.append(domElement)
    }

    function createRoot(container) { // 29395
        var root = {containerInfo: container}
        listenToAllSupportedEvents(container)
        return new ReactDOMRoot(root)
    }
    function createRoot$1(container) { // 29861
        return createRoot(container)
    }

    exports.createRoot = createRoot$1
})(this.ReactDOM = {});


/****************************** app.js ******************************/
(function() {
    const container = document.createElement('div')
    document.body.append(container)
    const root = ReactDOM.createRoot(container)
    root.render(React.createElement(
        'button',
        {
            onClick: function() {
                // debugger
                console.log('hello')
            },
        },
        'Click Me!'
    ))
})();
