/*
Starting point
*/

/****************************** react.js ******************************/
(function(exports) {
    // empty
})(this.React = {});

/****************************** react-dom.js ******************************/
(function(exports) {
    // empty
})(this.ReactDOM = {});

/****************************** app.js ******************************/
(function() {
    const container = document.createElement('div')
    document.body.append(container)
    
    const button = document.createElement('button')
    button.textContent = 'Click me'
    button.onclick = function() {
        console.log('hello')
    }
    container.append(button)
})();
