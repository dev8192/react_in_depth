/*
Starting point (no React)
*/

const container = document.createElement('div')
document.body.append(container)

const button = document.createElement('button')
button.textContent = 'Click me'
button.onclick = function() {
    console.log('hello')
}
container.append(button)
