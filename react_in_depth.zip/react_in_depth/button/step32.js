/*
Add:
dispatchEventForPluginEventSystem
extractEvents$5

When I click a button, it is not just 'click'.
It is a series of events:
pointerover / mouseover
(pointermove / mousemove)
pointerdown / mousedown
focusin
pointerup / mouseup
click

The following functions are called
even if we don't care about these events:

dispatchEvent | dispatchDiscreteEvent | dispatchContinuousEvent
    dispatchEventWithEnableCapturePhaseSelectiveHydrationWithoutDiscreteEventReplay
        dispatchEventForPluginEventSystem
            batchedUpdates
                batchedUpdates$1
                    (anonymous)
                        dispatchEventsForPlugins
                            processDispatchQueue

This seems rather inefficient.

*/

/****************************** react.js ******************************/
(function(exports) {
    function createElement(type, config, children) { // 774
        var props = {}
        props.children = children
        return { type, props }
    }
    function createElementWithValidation() {
        var element = createElement.apply(this, arguments)
        return element
    }
    exports.createElement = createElementWithValidation
})(this.React = {});

/****************************** react-dom.js ******************************/
(function(exports) {
    var allNativeEvents = new Set([ // 145
        'click'
    ])
    var IS_EVENT_HANDLE_NON_MANAGED_NODE = 1; // 3818
    var IS_NON_DELEGATED = 1 << 1;
    var IS_CAPTURE_PHASE = 1 << 2;
    var SHOULD_NOT_PROCESS_POLYFILL_EVENT_PLUGINS = IS_EVENT_HANDLE_NON_MANAGED_NODE | IS_NON_DELEGATED | IS_CAPTURE_PHASE;
    var batchedUpdatesImpl // 3943

    function batchedUpdates(fn, a, b) { // 3969
        return batchedUpdatesImpl(fn, a, b)
    }

    function setBatchingImplementation(_batchedUpdatesImpl) { // 3985
        batchedUpdatesImpl = _batchedUpdatesImpl
    }
    var invokeGuardedCallbackImpl
    invokeGuardedCallbackImpl = function invokeGuardedCallbackDev() { // 4103
        function callCallback() {
            didCall = true;
            restoreAfterDispatch();
            func.apply(context, funcArgs);
            didError = false;
        }
        fakeNode.dispatchEvent(evt)
    }
    var reporter = { // 4242
        onError: function (error) {
            hasError = true;
            caughtError = error;
        }
    };
    function invokeGuardedCallback() { // 4262
        invokeGuardedCallbackImpl$1.apply(reporter, arguments)
    }
    function invokeGuardedCallbackAndCatchFirstError() { // 4278
        invokeGuardedCallback.apply(this, arguments)
    }

    function createEventListenerWrapperWithPriority(targetContainer, domEventName, eventSystemFlags) { // 6413
        return dispatchEvent.bind(null, domEventName, eventSystemFlags, targetContainer)
    }

    function dispatchEvent(domEventName, eventSystemFlags, targetContainer, nativeEvent) { // 6464
        dispatchEventWithEnableCapturePhaseSelectiveHydrationWithoutDiscreteEventReplay(
            domEventName, 
            eventSystemFlags, 
            targetContainer, 
            nativeEvent
        )
    }

    function dispatchEventWithEnableCapturePhaseSelectiveHydrationWithoutDiscreteEventReplay( // 6474
        domEventName, 
        eventSystemFlags, 
        targetContainer, 
        nativeEvent
    ) {
        dispatchEventForPluginEventSystem(
            domEventName,
            eventSystemFlags,
            nativeEvent,
            return_targetInst,
            targetContainer
        )
    }

    var return_targetInst = null // 6525
    function extractEvents$5(
        dispatchQueue,
        domEventName,
        targetInst,
        nativeEvent,
        nativeEventTarget,
        eventSystemFlags,
    ) { // 9010
        extractEvents$4(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget, eventSystemFlags)
        var shouldProcessPolyfillPlugins = (eventSystemFlags & SHOULD_NOT_PROCESS_POLYFILL_EVENT_PLUGINS) === 0
        if (shouldProcessPolyfillPlugins) {
            extractEvents$2(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget);
            extractEvents$1(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget);
            extractEvents$3(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget);
            extractEvents(dispatchQueue, domEventName, targetInst, nativeEvent, nativeEventTarget);
        }
    }
    function executeDispatch() { // 9051
        invokeGuardedCallbackAndCatchFirstError()
    }
    function processDispatchQueueItemsInOrder() { // 9058
        executeDispatch()
    }

    function processDispatchQueue(dispatchQueue, eventSystemFlags) { // 9092
        debugger
        for (var i = 0; i < dispatchQueue.length; i++) {
            var _dispatchQueue$i = dispatchQueue[i],
                event = _dispatchQueue$i.event,
                listeners = _dispatchQueue$i.listeners;
            processDispatchQueueItemsInOrder(event, listeners)
        }
    }

    function dispatchEventsForPlugins( // 9106
        domEventName,
        eventSystemFlags,
        nativeEvent,
        targetInst,
        targetContainer
    ) {
        var dispatchQueue = []
        extractEvents$5(dispatchQueue)
        processDispatchQueue(dispatchQueue)
    }

    function listenToNativeEvent(domEventName, isCapturePhaseListener, target) { // 9129
        var eventSystemFlags = 0
        if (isCapturePhaseListener) {
            eventSystemFlags |= IS_CAPTURE_PHASE
        }
        addTrappedEventListener(target, domEventName, eventSystemFlags, isCapturePhaseListener)
    }
    function listenToAllSupportedEvents(rootContainerElement) { // 9145
        allNativeEvents.forEach(function (domEventName) {
            listenToNativeEvent(domEventName, false, rootContainerElement)
            listenToNativeEvent(domEventName, true, rootContainerElement)
        })
    }

    function addTrappedEventListener(
        target,
        eventType,
        eventSystemFlags,
        isCapturePhaseListener,
    ) { // 9172
        var listener = createEventListenerWrapperWithPriority(target, eventType, eventSystemFlags)
        if (isCapturePhaseListener) {
            target.addEventListener(eventType, listener, true)
        } else {
            target.addEventListener(eventType, listener, false)
        }
    }

    function dispatchEventForPluginEventSystem( // 9214
        domEventName,
        eventSystemFlags,
        nativeEvent,
        targetInst,
        targetContainer
    ) {
        batchedUpdates(function () {
            return dispatchEventsForPlugins(domEventName, eventSystemFlags, nativeEvent);
        })
    }

    function batchedUpdates$1(fn, a) { // 26189
        return fn(a)
    }

    function ReactDOMRoot(internalRoot) { // 29333
        this._internalRoot = internalRoot
    }
    ReactDOMRoot.prototype.render = function(children) { // 29337
        var root = this._internalRoot
        const domElement = document.createElement(children.type)
        domElement.textContent = children.props.children
        root.containerInfo.append(domElement)
    }

    function createRoot(container) { // 29395
        var root = {containerInfo: container}
        listenToAllSupportedEvents(container)
        return new ReactDOMRoot(root)
    }
    setBatchingImplementation(batchedUpdates$1) // 29838
    function createRoot$1(container) { // 29861
        return createRoot(container)
    }

    exports.createRoot = createRoot$1
})(this.ReactDOM = {});


/****************************** app.js ******************************/
(function() {
    const container = document.createElement('div')
    document.body.append(container)
    const root = ReactDOM.createRoot(container)
    root.render(React.createElement(
        'button',
        {
            onClick: function() {
                // debugger
                console.log('hello')
            },
        },
        'Click Me!'
    ))
})();
