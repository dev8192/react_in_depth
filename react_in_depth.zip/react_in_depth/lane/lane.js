/*
This program demonstrates the concept of lanes in React

*/

var NoLanes                      = 0b00000000_00000000_00000000_00000000 // 0
var NoLane                       = 0b00000000_00000000_00000000_00000000 // 0

var SyncLane                     = 0b00000000_00000000_00000000_00000001 // 1
var InputContinuousHydrationLane = 0b00000000_00000000_00000000_00000010 // 2
var InputContinuousLane          = 0b00000000_00000000_00000000_00000100 // 4
var DefaultHydrationLane         = 0b00000000_00000000_00000000_00001000 // 8
var DefaultLane                  = 0b00000000_00000000_00000000_00010000 // 16
var TransitionHydrationLane      = 0b00000000_00000000_00000000_00100000 // 32

var TransitionLanes              = 0b00000000_00111111_11111111_11000000 // 4194240
var TransitionLane1              = 0b00000000_00000000_00000000_01000000 // 64
var TransitionLane2              = 0b00000000_00000000_00000000_10000000 // 128
var TransitionLane3              = 0b00000000_00000000_00000001_00000000 // 256
var TransitionLane4              = 0b00000000_00000000_00000010_00000000 // 512
var TransitionLane5              = 0b00000000_00000000_00000100_00000000 // 1024
var TransitionLane6              = 0b00000000_00000000_00001000_00000000 // 2048
var TransitionLane7              = 0b00000000_00000000_00010000_00000000 // 4096
var TransitionLane8              = 0b00000000_00000000_00100000_00000000 // 8192
var TransitionLane9              = 0b00000000_00000000_01000000_00000000 // 16384
var TransitionLane10             = 0b00000000_00000000_10000000_00000000 // 32768
var TransitionLane11             = 0b00000000_00000001_00000000_00000000 // 65536
var TransitionLane12             = 0b00000000_00000010_00000000_00000000 // 131072
var TransitionLane13             = 0b00000000_00000100_00000000_00000000 // 262144
var TransitionLane14             = 0b00000000_00001000_00000000_00000000 // 524288
var TransitionLane15             = 0b00000000_00010000_00000000_00000000 // 1048576
var TransitionLane16             = 0b00000000_00100000_00000000_00000000 // 2097152

var RetryLanes                   = 0b00000111_11000000_00000000_00000000 // 130023424
var RetryLane1                   = 0b00000000_01000000_00000000_00000000 // 4194304
var RetryLane2                   = 0b00000000_10000000_00000000_00000000 // 8388608
var RetryLane3                   = 0b00000001_00000000_00000000_00000000 // 16777216
var RetryLane4                   = 0b00000010_00000000_00000000_00000000 // 33554432
var RetryLane5                   = 0b00000100_00000000_00000000_00000000 // 67108864
var SomeRetryLane                = 0b00000000_01000000_00000000_00000000 // RetryLane1

var SelectiveHydrationLane       = 0b00001000_00000000_00000000_00000000 // 134217728
var NonIdleLanes                 = 0b00001111_11111111_11111111_11111111 // 268435455

var IdleHydrationLane            = 0b00010000_00000000_00000000_00000000 // 268435456
var IdleLane                     = 0b00100000_00000000_00000000_00000000 // 536870912
var OffscreenLane                = 0b01000000_00000000_00000000_00000000 // 1073741824

function getLabelForLane(lane) {
    if (lane & SyncLane) return                     'Sync'
    if (lane & InputContinuousHydrationLane) return 'InputContinuousHydration'
    if (lane & InputContinuousLane) return          'InputContinuous'
    if (lane & DefaultHydrationLane) return         'DefaultHydration'
    if (lane & DefaultLane) return                  'Default'
    if (lane & TransitionHydrationLane) return      'TransitionHydration'
    if (lane & TransitionLanes) return              'Transition'
    if (lane & RetryLanes) return                   'Retry'
    if (lane & SelectiveHydrationLane) return       'SelectiveHydration'
    if (lane & IdleHydrationLane) return            'IdleHydration'
    if (lane & IdleLane) return                     'Idle'
    if (lane & OffscreenLane) return                'Offscreen'
}

const arr = [
    SyncLane,
    InputContinuousHydrationLane, InputContinuousLane,
    DefaultHydrationLane, DefaultLane,
    TransitionHydrationLane,
    TransitionLane1, TransitionLane2, TransitionLane3, TransitionLane4,
    TransitionLane5, TransitionLane6, TransitionLane7, TransitionLane8,
    TransitionLane9, TransitionLane10, TransitionLane11, TransitionLane12,
    TransitionLane13, TransitionLane14, TransitionLane15, TransitionLane16,
    RetryLane1, RetryLane2, RetryLane3, RetryLane4, RetryLane5, SomeRetryLane,
    SelectiveHydrationLane,
    IdleHydrationLane, IdleLane, OffscreenLane,
]
for (const item of arr) {
    console.log(getLabelForLane(item))
}
